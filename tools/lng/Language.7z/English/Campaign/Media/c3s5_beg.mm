ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  150  375  516   0300   00000       18390      4    "Old wolves do not die gracefully. Warriors their entire lives, they do not know how to live when they grow old and their fangs fall out. Such it is with Mongols as well. Genghis Khan was now eighty years old."     37 15 9 
1   TEXT  199  406  404   0300   18390       06687      4    "On the night when we knew that our glorious conquest was about to end, Genghis summoned his sons to his tent."     37 15 9 
2   TEXT  119  119  574   0300   25075       18390      4    "They found their father shivering before a fire, delirious with pain. 'My descendants will wear gold,' he said, 'they will eat the finest meats and ride the finest horses � and forget to whom they owe it all. A deed is not glorious until it is finished.'"     37 15 9 
3   TEXT  378  178  262   0300   43467       06687      4    "And he refused to die until Ogatai, his third son, promised to continue the war."     37 15 9 
4   TEXT  250  120  320   0300   50155       04365      4    "Ogatai emerged from the tent, carrying his father's bow, and declared"     37 15 9 
5   TEXT  216  153  394   0300   54520       06998      4    "'This storm is not yet finished. I still hear the sound of lightning, and it strikes in Poland.'"     37 15 9 
6   TEXT  194  141  442   0300   61519       09534      4    "The church bells rang in Europe when they saw our horde pouring out of the mountains. The armies of Bohemia and Germany hastened to Poland's defense."     37 15 9 
7   TEXT  170  245  494   0300   71053       11308      4    "To them, our army might have been from the Underworld itself, still commanded by the shade of the Great Khan."     37 15 9 




8   PICT  358  086  400   400    00000      18390      0    ""                                 255 255 255 
9   PICT  150  087  400   400    18390      06687      1    ""                                 255 255 255 
10   PICT  099  198  400   400    25075      18390       2    ""                                 255 255 255 
11  PICT  101  089  400   400    43467      06687       3    ""                                 255 255 255 
12   PICT  300  145  400   400    50155      04365      4    ""                                 255 255 255 
13  PICT  101  207  400   400    54520      06998      5    ""                                 255 255 255 
14  PICT  177  209  400   400    61519      09534       6    ""                                 255 255 255 
15  PICT  090  317  400   400    71053      11308       7    ""                                 255 255 255 



17  SND   0    0    0     0      0000       1000        0    "c3s5.mp3"                         0   0   0 
18 WND    0    0    0     0      0   82361    0  ""  0 0 0      
