ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  305  273  244    50     0000      08379        3     "From the Journal of Guy Josselyne"     12  9  4   
2   TEXT  268  293  314    50     0000      08379        3     "February 19, Army Camp near Vaucouleurs"     12  9  4   

3   PICT  329  102  400   400    08379     10765        0     "" 0 0 0
4   TEXT  160  200  300   200     08379     10765        3     "This morning I awoke to visions of fire and steel. These nightmares come more often now that I have seen my beloved France eaten away in years of war." 12  9  4 

5   PICT  391  84  400   400     19144     12154        1     "" 0 0 0
6   TEXT  115  288  280   110    19144     12154        3     "I wandered through camp ignoring the new snowfall, but observing the wounds and weariness of every soldier under my command, observing the desperation in their eyes."     12  9  4

7   PICT  269  106  400   400    31299     17912        2     "" 0 0 0
8   TEXT  153  181  268   150    31299     17912        3     "It was then that I first saw the girl. She told us that her name was Joan. She told us she was but a peasant, who did not know how to ride or fight. She told us that she intended to rescue France. The darkness lifted from the men's souls. "  12  9  4

9   PICT  452  166  400   400    49211     12088        3     "" 0 0 0
10  TEXT  176  119  446   74     49211     12088       3     "Her voice rang with conviction, and we drank in her every word. I may have lost my faith, but Joan has not lost hers, and that is enough for me."     12  9  4  

11  PICT  121  151  400   400    61299      10039        4     "" 0 0 0
12  TEXT  350  214  320   64     61299      10039        3     "Joan has asked our ragged band of soldiers to take her to Chinon, where the rightful ruler of France, the Dauphin, hides from his foes."     12  9  4  

13  PICT  096  157  400   400     71339     20658       5     "" 0 0 0
rem 14  PICT  096  157  400   400    71399     20658        6     "" 0 0 0
15  TEXT  170  110  486   68     71399     20658        3     "The war-torn land between is infested with enemy marauders, and we will lose many men.  Death is by now an old companion, but for Joan, we will face it again."     12  9  4 

16  SND   0    0    0     0      4          1000        0     "c1s1.mp3" 0 0 0 

17  WND   0    0    0     0      0         91997        0     "" 0 0 0      
