ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  150  435   520   500    00000  12859        3     "Barbarossa's soldiers were devastated. Several knights committed suicide. Others converted and joined the Saracens, so convinced were they that God Himself had deserted them."     0   0   0
2  TEXT  249  119   360   500    12859  06737        3     "However, a handful of knights were not yet willing to board a ship bound for Europe."     0   0   0
3  TEXT  145  140   280   500    19597  12213        3     "The body of mighty Barbarossa was fished out of the river, pickled in vinegar, and sealed in a barrel. The army of the Holy Roman Empire would not be joining in the Crusade."     0   0   0
4  TEXT  165  125   520   500    31810  15906        3     "Yet there was still a chance for a small victory. The surviving knights vowed to take Barbarossa's body on to Jerusalem. Even in death, the emperor would keep his promise!"     0   0   0

5   PICT  238  58   400   400    00000  12859        0     ""                                 255 255 255
6   PICT  111  94   400   400    12859  06737         1     ""                                 255 255 255
7   PICT  321  71   400   400    19597  12213        2     ""                                 255 255 255
8   PICT  60  129   400   400    31810  15906        3     ""                                 255 255 255

18 WND    0    0    0     0      0      47716        0      ""    0   0    0      

15  SND   0    0    0     0      0000      15000       0     "c4s6.mp3"                     0   0   0 

