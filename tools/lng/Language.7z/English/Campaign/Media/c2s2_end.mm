ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  111  560   94     00000      13370      2     "Although I am still prisoner, Saladin and his generals dine with me. Over meals we discuss mathematics and astronomy. I never imagined a race of desert folk could be so wise."     0   0   0   
2   TEXT  175  411  490   114    13370      11521      2     "Baghdad, the Saracen capital, is the most civilized city in the world, with free hospitals, public baths, a postal service, and banks with branches as far away as China."     0   0   0   
3   TEXT  200  419  478   122    24891      19365      2     "But as we eat, talk inevitably turns to war. Reynald's pirate vessels now rot at the bottom of the Red Sea. His raids have stopped. Reynald has escaped, but I suspect Saladin shall neither forgive nor forget."     0   0   0   

8   PICT  100   206   400   400    00000     13370       0     ""                                 255 255 255 
9   PICT  100   78    400   400    13370     11521       1     ""                                 255 255 255 
10  PICT  186   82    400   400    24891     19365       2     ""                                 255 255 255 


17  SND   0    0    0     0      4         0000           0     "c2s2end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   44257   0  ""  0 0 0      

