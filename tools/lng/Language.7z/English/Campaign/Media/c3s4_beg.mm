ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0   TEXT  129  431  546   0650   00000      09796       4    "Sleep in the saddle. Drink the rain. Eat nothing but dried meat, dried milk, and horse blood. Such is the life of a Mongol at war."     37 15 9   
1   TEXT  220  128  408   0650   09796      06364       4    "At night we are rewarded with fermented yak's milk and the promise of Persian treasures."     37 15 9
2   TEXT  183  490  442   0650   16161      06363       4    "Driven on by the words of the Great Khan we have crossed miles of the Asian continent at a full gallop."     37 15 9 
3   TEXT  245  200  338   0650   22524      03506       4    "Before us lies the vast empire of Persia."     37 15 9 
4   TEXT  164  443  478   0650   26037      10935       4    "The Khwarazm Shah will be given one chance to submit, and then his cities will be pulled down brick by brick. But not all of us head into Persia."     37 15 9 
5   TEXT  315  422  374   0650   36966      18831       4    "Genghis has sent Subotai Ba'atur of the Reindeer People north into Russia. The Russian principalities are disorganized, and Genghis hopes that Subotai can break them one by one. Then the borders of Mongolia will cover all of Asia."     37 15 9 



8   PICT  192  85   400   400    00000      09796      0    ""                                 255 255 255 
9   PICT  100  187  400   400   09796       06364      1    ""                                 255 255 255 
10   PICT  347  127  400   400    16161      06363      2    ""                                 255 255 255 
11  PICT  097  301  400   400    22524      03506      3    ""                                 255 255 255 
12  PICT  196  088  400   400    26037      10935      4    ""                                 255 255 255 
13  PICT  097  147  400   400    36966      18831      5    ""                                 255 255 255 





17  SND   0    0    0     0      0000       1000        0    "c3s4.mp3"                         0   0   0 
18 WND    0    0    0     0      0   55797     0  ""  0 0 0      
