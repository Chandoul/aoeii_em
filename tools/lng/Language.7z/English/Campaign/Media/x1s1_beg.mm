ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  390  085  300   200    00000     12137        4     "A severed head on a pike seemed such a grisly trophy to be displayed in the chapel at Ch�lons.  And yet it took me weeks before I got up the nerve to ask Father Armand why he kept it." 12  9  4 
2   TEXT  360  200  300   400    12137     25461        4     "The ancient priest stared out the window for a long time, recalling days gone by.  'I was there,' he said finally.  'At the battle of the Catalaunian Fields�fighting alongside Aetius and Theodoric the Goth.'  I knew there had been a battle here, decades ago.  Peasants still overturn skeletons and broken shields with their plows from time to time." 12  9  4 
3   TEXT  160  085  300   200    37598     16547        4     "�Who was it, Father?�  I asked him.  �Who were you fighting?�  He turned back to regard me, paralyzing me in his old-man�s stare.  �Attila the Hun,� he said.  And then he told me the story." 12  9  4 
4   TEXT  250  085  350   130    54056     11238        4     "The Huns rode out from the wilderness sometime in the 400s, eager to feast on a Roman Empire weak from internal corruption and the expansion of other barbarian tribes."  12  9  4 
5   TEXT  250  085  350   130    65294     15603        4     "It was the Huns who drove many of these other barbarians before them.  They were terrifying warriors from the steppes of Asia, their bodies disfigured from ritual scarring, their legs deformed from a near lifetime in the saddle."  12  9  4 
6   TEXT  400  220  280   200    80898     26981        4     "Despite their fearsome aspect, the Huns might have been little more than raiders, had it not been for the leadership of Attila. He called himself the Scourge of God.  Attila and his brother Bleda led the Huns not just to raid, but to devastate Scythia and Persia." 12  9  4 



// DO NOT USE  6   PICT  263  181  400   400    00000     15000        0     "" 0 0 0
7   PICT  095  201  400   400    00000     12137        1     "" 0 0 0
8   PICT  084  074  400   400    12137     25461        2     "" 0 0 0
9   PICT  294  139  400   400    37598     16457       3     "" 0 0 0
10  PICT  140  249  400   400    54056     26842        4     "" 0 0 0
11  PICT  107  089  400   400    80898     26981        5     "" 0 0 0


16  SND   0    0    0     0      4          1000        0     "xc1s1.mp3" 0 0 0 

17  WND   0    0    0     0      0          107879        0     "" 0 0 0      
