ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  170  080  500   200    00000     21919        3     "How do I know so much of my Cid, Rodrigo D�az?  I am Ximena of Asturias, and I am the Dona of this Castle.  Rodrigo and I were married in Castille in 1075.  Those were among the happiest days of my life, at least when my husband was not being sent to do battle against the Moors."	 12  9  4 
2   TEXT  170  080  500   200    21919     24148        3     "Far to the East, in the Holy Land, they speak of only one Muslim Expansion -- that of the Seljuk Turks.  But here, in Spain, we speak of another -- the Moors.  The Moors ruled southern Spain for so long that Christian and Muslim often lived side by side with little animosity.  Such was the case in the City of Toledo, which was in Moorish lands, but inhabited by Christians as well."	 12  9  4 
3   TEXT  490  200  200   200    46068     11661        3     "A political assassination had plunged the city of Toledo into a civil war.  Seeing a chance to expand his empire, King Alfonso struck at Toledo under the pretence of restoring order."	 12  9  4 
4   TEXT  260  150  300   200    57729     17781        3     "He ordered the Cid to command the army, though one must wonder if once again he was intentionally putting the Cid in harm�s way."   12  9  4 



5   PICT  176  194  400   400    00000     21919        0     "" 0 0 0
6   PICT  175  189  400   400    21919     24148        1     "" 0 0 0
7   PICT  131  076  400   400    46068     11661        2     "" 0 0 0
8   PICT  149  253  400   400    57729     17781        3     "" 0 0 0


16  SND   0    0    0     0      4          1000        0     "xc2s2.mp3" 0 0 0 

17  WND   0    0    0     0      0          75511        0     "" 0 0 0      
