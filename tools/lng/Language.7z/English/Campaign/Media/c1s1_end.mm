ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  241  468  350   68    0000       14413        3     "As Joan's footsteps echoed down the marbled hall of the ch�teau, the fat and whispering dukes did naught but stare."     0   0   0   
2   TEXT  211  257  428   90    14413      13172        3     "The Dauphin himself seemed afraid as she kissed his feet. 'My gentle Dauphin,' she demanded, 'why does England claim what is ours? Why are you not crowned King of France as is your right?'"     0   0   0   
3   TEXT  160  100  410   48    27585      07058        3     "The courtiers began to murmur. The chamberlain whispered lies into the Dauphin's ear."     0   0   0   
4   TEXT  160  100  360   48    34644      05513        3     "But the Dauphin pushed the chamberlain away and rose to meet Joan's gaze."     0   0   0
5   TEXT  199  213  420   70    40157      06609        3     "She stands only to the shoulder of the shortest man, but all of us must look up to speak to her."     0   0   0   
6   TEXT  199  213  420   70    46767      16507        3     "I know not what silent conversation passed between the Dauphin and his would-be savior, but it was obvious that his majesty was in the same thrall as we."     0   0   0   

8   PICT  152   74   400   400    0000      14413        0     ""                                 255 255 255 
9   PICT  143   381   400   400    14413      13172       1     ""                                 255 255 255 
10   PICT  410  153    400   400    27585     12570     2      ""                                 255 255 255 
11   PICT  433  275   400   400    40157      23117     3      ""                                 255 255 255 

17  SND   0    0    0     0      4         0000           0     "c1s1end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   63274   0  ""  0 0 0      

