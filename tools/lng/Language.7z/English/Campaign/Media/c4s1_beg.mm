ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0  TEXT  175  120  500   500    00000      21024        3     "So you have come to hear the tale of Frederick Barbarossa?  Better order us another round. Maybe three. You see � it is a great tale. But then again, everything about the man was great."     0   0   0
1  TEXT  420  200  220   500    21024      17892        3     "Barbarossa was a man of great appetites � great ambitions � and a great, red beard. But the question � the question you want to know � is: Was that enough? Is the will of one man enough to forge an empire?"     0   0   0
2  TEXT  511  126  144   500    38916      14675        3     "For there was no Holy Roman Empire at that time, only a gaggle of quarrelling city-states. These dubiously loyal princedoms were more interested in a loose confederation than a unified empire."     0   0   0
3  TEXT  132  350  250   500    53591      18134       3     "But Barbarossa, he believed that he was the emperor by will of God, and he intended to bring the Holy Roman Empire back to its former glory. If that meant crushing all of the German princes, well, so be it."     0   0   0


4   PICT  80  198   400   400    00000      21024        0     ""                                 255 255 255
5   PICT  110  93   400   400    21024      17892        1     ""                                 255 255 255
6   PICT  94   86   400   400    38916      14675        2     ""                                 255 255 255
7   PICT  337  104   400   400   53591      18134        3     ""                                 255 255 255

18 WND    0    0    0     0      0   71726   0  ""  0 0 0      



15  SND   0    0    0     0      0000      15000       0     "c4s1.mp3"                     0   0   0 

