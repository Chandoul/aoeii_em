ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
1   TEXT  339  299  144   0050   00000      03478       3    "June 25, Orl�ans"     0   0   0   
2   TEXT  140  250  240   0100   03478      11531       3    "Dead France is returning to life. Our army swells with new recruits. In olden times, men swore fealty only to their particular lord."     0   0   0   
3   TEXT  150  100  240   0100   15009      12575       3    "Now we fight not for insolent lords and ladies, but for France. For all of us, Joan is France. There is no distinction in our minds."     0   0   0   
4   TEXT  196  120  440   0250   27584      13601       3    "The Dauphin himself has arrived in Orl�ans. Never have I seen such a celebration. France needs a king, so we must escort the Dauphin to Rheims where he can be properly crowned."     0   0   0   
5   TEXT  165  105  520   0100   41185      09898       3    "Yet the city of Rheims is dangerously menaced by the Anglo-Burgundian army. The cities of Troyes and Chalon also bar the way."     0   0   0   
6   TEXT  175  105  520   0100   51083      11308       3    "Joan commands that we must liberate all three cities before the coronation, and we eagerly seek to fight."     0   0   0   

8   PICT  373  091  400   400    03478      24106       0    ""                                 255 255 255 
9   PICT  155  240  400   400    27584      13601       1    ""                                 255 255 255 
10  PICT  261  200   400   400    41185      21206       2    ""                                 255 255 255 

17  SND   0    0    0     0      0000       1000        0    "c1s4.mp3"                         0   0   0 
18 WND    0    0    0     0      0   62392   0  ""  0 0 0      
