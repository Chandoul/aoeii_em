ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  254  306  454   60     00000     01857       2     "The first year of my freedom �"     0   0   0   
2   TEXT  120  120  344   128    01857     11314       2    "The fighting is over. The fire has gone out of Richard's lust for conquest. The two respected adversaries started speaking, finally, of peace."     0   0   0   
3   TEXT  152  108  512   144    13172     16806       2     "War is not gentle with men's health. Richard fell ill with a fever. Because he respected his enemy, Saladin sent Richard fruit and mountain snow to comfort him. Soon enough, Richard boarded a ship headed back to England. The Third Crusade is over."     0   0   0   
4   TEXT  153  387  556   148    29978     18657       2     "The final treaty was signed on September 2, 1192. By its terms, Jerusalem remains in Saracen hands, but Christian pilgrims are to be allowed to visit all the holy places, freely and safely. It seems a fitting compromise to a war that has been fought over religion and land."     0   0   0   
5   TEXT  114  94   610   148    48635     20931       2     "The war is over, but I do not think I shall ever see Normandy again. I want to see the steel foundries in Damascus and the gardens of the Caliph in Baghdad. I have never seen the mighty Krak de Chevalliers, now-fallen fortress of the Knights Templar. The Holy Land has many wondrous sites, and I can spend a lifetime here."     0   0   0   
6   TEXT  155  405  554   104    69566     20665       2     "It is peace in the Holy Land� for the moment. Sadly, in a land so small, home to so many different cultures, birthplace of three of the world's great religions, I suspect that blood may one day stain the sand again."     0   0   0   

8   PICT  415 99   400   400    01857     11314         0     ""                                 255 255 255 
9   PICT  139 238  400   400    13172     16806        1     ""                                 255 255 255 
10   PICT  114 88   400   400    29978     18657        2     ""                                 255 255 255 
11  PICT  354 235  400   400    48635     20931        3     ""                                 255 255 255 
12   PICT  171 78   400   400    69566     20665        4     ""                                 255 255 255 

17  SND   0    0    0     0      4         0000           0     "c2s6end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   90232   0  ""  0 0 0      

