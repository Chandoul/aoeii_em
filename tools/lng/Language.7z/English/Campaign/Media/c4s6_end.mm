ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0  TEXT  349  117  350   500    00000      18204        3     "There is a legend concerning every great king, from Arthur on through Barbarossa, that says the king will return someday when his country needs him. Myths and legends about the sleeping emperor were passed down in German folktales. The Holy Roman Empire did not endure."     0   0   0
1  TEXT  265  476  350   500    18204      07619        3     "She fell back into a patchwork of tiny nations. Some would say Barbarossa's rule was a failure."     0   0   0
2  TEXT  225  475  400   500    25824      08546        3     "But is it not a greater testament to the man that it was the force of his will alone that held the empire together?"     0   0   0
3  TEXT  300  472  400   500    34370      08739        3     "And what of Henry the Lion?  With Barbarossa gone, there was nothing stopping him from returning to the Holy Roman Empire."     0   0   0
4  TEXT  150  155  220   500    43110      13987        3     "But I am an old man now. What harm could I possibly do?"     0   0   0

5   PICT  65   15   400   400    00000      18204       0     ""                                 255 255 255
6   PICT  50   62   400   400    18204      07619       1     ""                                 255 255 255
7   PICT  315  72   400   400    25824      08546       2     ""                                 255 255 255
8   PICT  109  90   400   400    34370      08739       3     ""                                 255 255 255
9   PICT  241  124  400   400    43110      13987       4     ""                                 255 255 255

18 WND    0    0    0     0      0   57097  0  ""  0 0 0      

15  SND   0    0    0     0      000      15000       0     "c4s6end.mp3"                     0   0   0 

