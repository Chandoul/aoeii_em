ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  339  299  144   0050   00000      02587      3    "July 14, Bordeaux"     0   0   0   
2   TEXT  177  108  464   0400   02587      19051      3    "No Joan of Arc. A rich world made empty and poor! The English put her on trial as a heretic. Joan's mind was as sharp as her sword, and she avoided all the cunning verbal traps of her prosecutors."     0   0   0   
3   TEXT  319  201  354   0080   21638      06968      3    "In the end, Joan would not renounce her mission. The English found her guilty �"     0   0   0   
4   TEXT  319  201  354   0080   28606      03449      3    "� and burned her at the stake."     0   0   0   
5   TEXT  197  111  426   0450   32055      17542      3    "But her death is not in vain. 'La Pucelle' is the rallying cry as peasant and nobleman alike take arms. My army is an army of the people, and even without the king we are poised to strike at the English stronghold of Castillon."     0   0   0   
6   TEXT  150  170  600   0450   49597      07013      3    "A victory at Castillon will crush the English pretensions in France forever."     0   0   0   
7   TEXT  180  421  385   0100   56610      16485      3    "Should I die in this battle, I die for the Maid of Orl�ans. I die as a patriot of France."     0   0   0   

8   PICT  125   167  400   400   02587      19051      0    ""                                 255 255 255 
9   PICT  124   75   400   400   21638      06968      1    ""                                 255 255 255 
10   PICT  374   351  400   400   28606      03449      2    ""                                 255 255 255 
11  PICT  273   232  400   400   32055      17542      3    ""                                 255 255 255 
12   PICT  142   226  400   400   49597      07013      4    ""                                 255 255 255 
13   PICT  477   94   400   400   56610      16485      5    ""                                 255 255 255 

17  SND   0    0    0     0      0000       1000        0    "c1s6.mp3"                         0   0   0 
18 WND    0    0    0     0      0   73096   0  ""  0 0 0      
