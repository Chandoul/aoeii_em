ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204   410   475    400    0000      18123        0     "In villages throughout the Highlands, there is grim talk of skirmishes between Scotland and England. We lost the city of Dunbar this week. Scottish defenders broke ranks and fled. The English have an army that is larger and better trained."     66 57 20
2   TEXT  204   100   475    400    18123     15313        0     "To compete with them, we are going to need new recruits to pick up the spear, sword, or bow. We must remake these shepherds into soldiers."     66 57 20

3   PICT  87    49    400   400    0000      18123        0     ""                                 255 255 255 
4   PICT  151   164   400   400    18123     15313        1     ""                                 255 255 255 

5   SND      0     0     0     0       0     33436        0     "c8s3.mp3"                        0   0   0 

6   WND      0     0     0     0       0     33436        0     ""        0 0 0      
