ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  410   420   300    400    0000      14373        0     "Stirling was our first great victory. Even as we held the coastline, word came in that the Stirling Bridge had been held by a force of Scots led by the mythical knight of whom so many have spoken."     66 57 20
2   TEXT  410   385   300    400    14373      7500        0     "Now we know his name: Sir William Wallace, the Hammer of the English."     66 57 20
3   TEXT  204   90   475    400    21873     11888        0     "Edward Longshanks names Wallace a traitor and a criminal. But Sir William replies that he cannot be a traitor, since he never swore fealty to an English king."     66 57 20
4   TEXT  204   90   475    400    33761     14210        0     "With Wallace leading our armies, the men fight with renewed vigor. Perhaps the tide of our misfortunes is about to turn �"     66 57 20

5   PICT   54    81   400   400    0000      14373        0     ""                                 255 255 255 
6   PICT  125    58   400   400    14373      7500        1     ""                                 255 255 255 
7   PICT  169    86   400   400    21873     11888        2     ""                                 255 255 255 
8   PICT  161    80   400   400    33761     14210        3     ""                                 255 255 255 

9   SND     0     0     0     0       0     47972        0     "c8s5end.mp3"                        0   0   0 

10  WND     0     0     0     0       0     47972        0     ""        0 0 0      
