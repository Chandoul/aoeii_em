ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  173  433  468   0300   00000       16068      4    "Only one enemy stands in our way. France and the nations beyond are beaten from decades of Crusades. If we break Eastern Europe, then it is likely that all of Western Europe will surrender. But to break the East, we must defeat Hungary."     37 15 9 
1   TEXT  184  219  230   0300   16068       13162      4    "Hungary possesses the most formidable cavalry in all of Europe. They have not only the strength of European armor, but their horses are cousins to our own, having drifted in from across the Russian steppes."     37 15 9 
2   TEXT  148  180  520   0300   29230       11234      4    "The Sajo River that separates us from the army of Hungary is frozen so we will be unable to deploy boats. Instead, the battle will be won or lost over who controls the bridge."     37 15 9 
3   TEXT  157  155  510   0300   40465       09540      4    "Subotai is coming with reinforcements. If we can survive the charge of Hungarian knights until Subotai arrives, then we can hope to take the bridge."     37 15 9 
4   TEXT  121  385  564   0300   50006       22602      4    "Much rests on this simple bridge. If we capture the Sajo crossing, we capture Hungary. If Hungary falls, so falls Europe. With Europe and Asia under Mongolian command, our conquest of the world will be complete and final."     37 15 9 




8   PICT  196   095  400   400    00000      16068      0    ""                                 255 255 255 
9   PICT  389   098  400   400    16068      13162      1    ""                                 255 255 255 
10   PICT  164   299  400   400    29230      11234      2    ""                                 255 255 255 
11  PICT  136   237  400   400    40465      09540      3    ""                                 255 255 255 
12  PICT  102   092  400   400    50006      22602      4    ""                                 255 255 255 


17  SND   0    0    0     0      0000       1000        0    "c3s6.mp3"                         0   0   0 
18 WND    0    0    0     0      0   72608    0  ""  0 0 0      
