ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  350   095   300   400    0000      16114        0     "Now that we have militias stationed across the border, the English have slowed their raids. But facing Longshanks' army will be another matter. The wicked English king has yet to bring his famous longbows to bear."     66 57 20
2   TEXT  280   450   300   400    16114     8986         0     "Our militias can only get us so far. We are going to need more advanced weapons."     66 57 20

3   PICT  151   118   400   400    0000      16114        0     ""                                 255 255 255 
4   PICT  91    54    400   400    16114     8986         1     ""                                 255 255 255 

5   SND     0     0     0     0       0      25100       0     "c8s3end.mp3"                        0   0   0 

6   WND     0     0     0     0       0      25100       0     ""        0 0 0      
