ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  100  550   300    00000     23034        3     "Passed down to you by Cuauhtemoc, Jaguar Warrior of Tenochtitlan.  The gods were still uneasy, for that same year, another omen appeared.  The temple of the demon Huitzlopochtli burst suddenly into flame, although it was made of stone.  When the people hurried to pour water on the fire, it burned with even greater violence." 12  9  4 
2   TEXT  140  200  200   400    23034     19882        3     "I asked our emperor Montezuma what we needed to do to appease the gods.  His haughty priests made the predictable reply.  The Aztec Empire needed more prisoners.  The sun god and the rain god and even the feathered serpent, Quetzalcoatl, were angry deities that required sacrifice." 12  9  4 
3   TEXT  130  150  300   200    42916     13541        3     "Our city-state of Tenochtitlan is allied with two others, together composing the Triple Alliance.  Montezuma intended for the Triple Alliance to attack our long time enemies, the Tlaxcala." 12  9  4 
4   TEXT  130  200  200   300    56457     13825        3     "I sent the traditional shield, arrows and cloaks to the Tlaxcala, declaring to them that they would soon be attacked.  Then we marched out into the forests, our jaguar and eagle banners ready to clash with the heron banners of the Tlaxcala." 12  9  4 
5   TEXT  250  110  375   068    70283     08409        3     "Birds in the rain forest canopy took to the sky, eager to be away from the violence that was to come." 12  9  4 

6   PICT  113  180  400   400    00000     23034        0     "" 0 0 0
7   PICT  334  144  400   400    23034     19882        1     "" 0 0 0
8   PICT  294  104  400   400    42916     13541        2     "" 0 0 0
9   PICT  331  141  400   400    56457     13825        3     "" 0 0 0
10  PICT  099  160  400   400    70283     08409        4     "" 0 0 0



16  SND   0    0    0     0      4          1000        0     "xc3s2.mp3" 0 0 0 

17  WND   0    0    0     0      0          78692        0     "" 0 0 0      
