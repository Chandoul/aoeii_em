ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  192  405  436   300    00000    11631       3     "A century of English toil, blood, and victories was reversed in a little over a year by a teenage girl. The Hundred Years War has ended."     0   0   0   
2   TEXT  192  425  436   300    11631    13584       3     "Even more importantly, Joan's acts reignited a sense of French nationalism. Peasants and nobles alike no longer belonged to lords and kings, but to France herself."     0   0   0   
3   TEXT  412  138  286   300    25215    09743       3     "We will not let Joan be forgotten.  Already, statues and stained glass portraits have been commissioned in hundreds of towns and cities throughout France."     0   0   0   
4   TEXT  157  110  504   60    34959    07926       3     "Her verdict of guilt was rightfully reversed, and eventually Joan of Arc was beatified as a saint."     0   0   0   
5   TEXT  157  110  504   60    42885    07562       3     "Sometimes the outcome of history is determined by strength of arms, other times by happenstance."     0   0   0   
6   TEXT  157  110  504   60    50448    07523       3     "But in fifteenth century France, history was determined by the will of a young girl �"     0   0   0   
7   TEXT  157  110  504   60    57972    12477        3     "� the only person in history to command the armies of an entire nation at the age of seventeen."     0   0   0   

8   PICT  225    93   400   400    00000     11631     0      ""                                 255 255 255 
9   PICT  297   088   400   400    11631     13584     1      ""                                 255 255 255 
10   PICT  121   086   400   400    25215     09743     2      ""                                 255 255 255 
11   PICT  251  197   400   400    34959    23013     3      ""                                 255 255 255 
13   PICT  421  169   400   400    57972     12477     5      ""                                 255 255 255 

17  SND   0    0    0     0      4         000           0     "c1s6end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   70449   0  ""  0 0 0      

