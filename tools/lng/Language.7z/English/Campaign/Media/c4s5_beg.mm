ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  145  112  520   500    00000      13020        3     "The Holy Roman Empire was complete and, for the moment, both Germany and Italy swore fealty to Barbarossa. Alas, the peace was not to endure."     0   0   0
2  TEXT  175  108  500   500    13020      14964        3     "The Crusader states in Palestine were crumbling. A Saracen king named Saladin had evicted virtually every Crusader from their castle. The Pope called for a new Crusade, before the Holy Land became Saracen once again."     0   0   0
3  TEXT  145  170  225   500    27984      14089       3     "Remarkably, Barbarossa agreed to undertake this new Crusade for the pope he had fought so hard against. King Philip of France and England's Richard the Lionhearted had already boarded ships bound for the Middle East."     0   0   0
4  TEXT  190  421  440   500    42074      06403        3     "But Barbarossa's army was the largest by far, and there wasn't a fleet in Europe that could transport it."     0   0   0
5  TEXT  340  460  350   500    48477      08272        3     "The emperor would have to march overland, to Constantinople and through the land of the Turks to reach the rendezvous in Jerusalem."     0   0   0
6  TEXT  160  443  520   500    56749      15197        3     "Constantinople was the capitol of the Byzantine Empire and one of the most glorious cities on the globe. Barbarossa's army would be able to rest and resupply in Byzantium before it began the great march."     0   0   0

7   PICT  95  145    400   400    00000      13020        0     ""                                 255 255 255
8   PICT  116  192   400   400    13020      14964        1     ""                                 255 255 255
9   PICT  277  126   400   400    27984      14089        2     ""                                 255 255 255
10   PICT  075  086   400   400    42074      06403       3     ""                                 255 255 255
11   PICT  81   62   400   400     48477      08272       4     ""                                 255 255 255
12   PICT  97   86   400   400     56749      15197       5     ""                                 255 255 255

18 WND    0    0    0     0      0   71947   0  ""  0 0 0      

15  SND   0    0    0     0      0000      15000       0     "c4s5.mp3"                     0   0   0 

