ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  140  306  600   60    00000    04290       2     "The Holy City of Medina. Year fifteen of my capture �"     0   0   0
2  TEXT  165  109  478   98    04290    09177       2     "Volumes have I filled with my fatigued writings. Lord Saladin reads them only rarely. He speaks of greater events yet to come."     0   0   0
3  TEXT  118  250  270   224    13467    08359       2     "The political boundaries in this endless desert have shifted as a result of three Crusades. Four Crusader states now exist in the Holy Land."     0   0   0
4  TEXT  118  95  270   224    21826    09376       2     "After the Saracen victory in Egypt, the Crusader leaders realized that Saladin was worthy of their concern. They were quick to suggest a treaty."     0   0   0
5  TEXT  118  250  262   204    31203    09260       2     "I hoped that with peace at last upon us, I would be returned to my own folk, but this peace, so short-lived, is already broken."     0   0   0
6  TEXT  324  233 386   168    40464    10963       2     "And it is not Saracen, but Crusader that has violated his word of honor.  Reynald de Chatillon, a wicked French knight, has been raiding Arab territory in defiance of the treaty."     0   0   0
7  TEXT  372  359 344   162    51427    21390       2     "He attacks trade caravans, and his pirate ships threaten the Saracen holy cities of Medina and Mecca. Saladin, in his fury, has sworn to kill Reynald with his own hands."     0   0   0


10   PICT  464   245  400   400    04290      09177        0     ""                                 255 255 255
11   PICT  373   82   400   400    13467      26996        1     ""                                 255 255 255
12   PICT  144   172  400   400    40464      10963        2     ""                                 255 255 255
13   PICT  121   84   400   400    51427      21390        3     ""                                 255 255 255

18 WND    0    0    0     0      0   72817   0  ""  0 0 0      



15  SND   0    0    0     0      0000      1000       0     "c2s2.mp3"                     0   0   0 

