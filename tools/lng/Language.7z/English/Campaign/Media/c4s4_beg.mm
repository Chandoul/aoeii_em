ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  165  110  500   500    00000      20871        3     "As long as Barbarossa's knights were present, peace endured. But the emperor could not be everywhere at once. Whenever he went to Italy, Germany would flare up, and when Barbarossa returned to Germany the Italians began plotting again."     0   0   0
2  TEXT  190  420  450   500    20871      10522        3     "Milan had fallen, but the remainder of the Italian cities joined together in a confederation known as the Lombard League for the purpose of defeating Barbarossa."     0   0   0
3  TEXT  128  260  200   500    31393      08802        3     "If Barbarossa intended to make Italy part of the Holy Roman Empire, he would have to conquer the Lombard League city by city."     0   0   0
4  TEXT  260  135  320   500    40196      11410        3     "But Barbarossa still had a secret weapon: Henry the Lion and his seasoned troops."     0   0   0

5   PICT  69  194   400   400    00000      20871        0     ""                                 255 255 255
6   PICT  97  51    400   400    20871      10522        1     ""                                 255 255 255
7   PICT  325 102   400   400    31393      08802       2     ""                                 255 255 255
8   PICT  123 180   400   400    40196      11410       3     ""                                 255 255 255

18 WND    0    0    0     0      0   51606   0  ""  0 0 0      

15  SND   0    0    0     0      0000      15000       0     "c4s4.mp3"                     0   0   0 

