ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  115  306  600   60    00000      04735       2    "Jerusalem.  Twenty years have I been with the Saracens �"     0   0   0   
2   TEXT  166  404  502   120   04735      16667       2    "Saladin's target is Jerusalem. The great, ancient city is sacred to Christianity, Judaism, and Islam and is the virtual capital of the Holy Land. If there can be a victor in this endless conflict, it will be the army who holds Jerusalem."     0   0   0   
3   TEXT  152  427  554   102   21403      17094       2    "To complicate matters, Saladin is determined not to harm the city itself. If a single holy shrine is damaged, the populace might well view Saladin not as a liberator but as yet another conqueror."     0   0   0   

8   PICT  162  78  400   400    04735     16667       0    ""                                 255 255 255 
9   PICT  148  82  400   400    21403     17094       1    ""                                 255 255 255 


17  SND   0    0    0     0      0000       1000        0    "c2s4.mp3"                         0   0   0 
18 WND    0    0    0     0      0   38498   0  ""  0 0 0      
