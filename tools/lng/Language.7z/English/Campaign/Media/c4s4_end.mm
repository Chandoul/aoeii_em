ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  145  140  520   500    00000      12717        3     "Henry the Lion was immediately banished to England. Separated from his wealth and army, there was little more he could do to plague Barbarossa."     0   0   0
2  TEXT  133  445  600   500    12717      05549        3     "After six campaigns down to Italy, Barbarossa was weary of crossing the Alps."     0   0   0
3  TEXT  150  159  520   500    18266      09176        3     "The fighting ended with the signing of the Treaty of Constance, which said effectively that the emperor and the pope were equals."     0   0   0
4  TEXT  155  225  200   500    27442      07215       3     "It was a tenuous peace, and one that seemed unlikely to endure when suddenly the pope died."     0   0   0
5  TEXT  150  116  520   500    34658      21812        3     "The new pope was less interested in squabbling with the emperor than he was in events down south. You see, the Europeans were being driven out of the Holy Land. It was time for another Crusade."     0   0   0

6   PICT  106  201   400   400   00000      12717        0     ""                                 255 255 255
7   PICT  302  66   400   400    12717      05549       1     ""                                 255 255 255
8   PICT  261  274   400   400   18266      09176       2     ""                                 255 255 255
9   PICT  347  86   400   400    27422      07215       3     ""                                 255 255 255
10   PICT  234  173   400   400   34658      21812        4     ""                                 255 255 255

18 WND    0    0    0     0      0  56470 0  ""  0 0 0      

15  SND   0    0    0     0      0      15000       0     "c4s4end.mp3"                     0   0   0 

