ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  110  110  510   200    00000     28885        3     "Passed down to you by Cuauhtemoc, Emperor of Tenochtitlan.  The Spanish will return soon.  I had hoped that Cort�z would continue fleeing back from whence he came, but he stopped to regroup at Tlaxcala.  I imagine that he could not stand the thought of returning to Spain while we still had treasuries of gold hidden from him.  Still dreaming of gold and glory, the Spanish pledged themselves to another assault on Tenochtitlan." 12  9  4 
2   TEXT  400  220  300   100    28885     12074        3     "In Tlaxcala, Cort�z constructed many war boats on dry land.  Then he had the craft broken down and carried through the rain forest, only to be rebuilt on Lake Texcoco." 12  9  4 
3   TEXT  400  220  300   100    40960     07801        3     "He knows that my Aztec warriors can defend the bridges leading into Tenochtitlan, but we are vulnerable from the water." 12  9  4 
4   TEXT  460  230  200   200    48761     11331        3     "I called the warriors to one final battle.  The priests attempted to encourage the troops by calling upon the Aztecs to defend their ancient gods and their glorious city."  12  9  4 
5   TEXT  140  110  510   200    60093     17641        3     "They sent up smoke signals to declare that the Aztecs were ready for war, as I climbed the steps of the great temple and sounded the shell trumpet.  Tenochtitlan would be under siege soon, and the brave Aztecs would die before we would see her captured." 12  9  4 



6   PICT  319  206  400   400    00000     28885        0     "" 0 0 0
7   PICT  102  167  400   400    28885     19876        1     "" 0 0 0
8   PICT  116  114  400   400    48761     11331        2     "" 0 0 0
9   PICT  238  315  400   400    60093     17641        3     "" 0 0 0



16  SND   0    0    0     0      4          0000        0     "xc3s6.mp3" 0 0 0 

17  WND   0    0    0     0      0          77734        0     "" 0 0 0      
