ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  260  368  350   200    00000      09287       3     "The old priest hung his head as he related what happened next, and I could tell the weight of the memories caused him great sorrow."     0   0   0   
2   TEXT  241  100  350   200    09287      12445       3     "Attila would stop at nothing until he reached his fianc�e, Honoria, and his goal of ruling the Roman Empire.  The ravaging of Gaul was unprecedented."     0   0   0   
3   TEXT  241  100  350   200    21733      15764       3     "People were tortured, their bodies torn asunder by wild horses, or their bones crushed under the weight of rolling wagons.  Their unburied limbs were abandoned on the public roads as prey to dogs."     0   0   0   
4   TEXT  241  130  350   200    37498      14513       3     "Heads on stakes stretched from Gaul clear back to the Danube River, from whence the Huns had come.  They lay siege to Orleans, for Attila had learned much of siegecraft since he had faced the walls of Constantinople."     0   0   0   
5   TEXT  241  148  350   200    52012      15162       3     "But as the Huns set to their fell task, a great cloud of dust appeared on the horizon.  Aetius and the Roman army had come."     0   0   0   


6   PICT  240  045  400   400   00000      09287       0     ""                                 255 255 255 
7   PICT  108  131  400   400   09287      12445     1     ""                                 255 255 255 
8   PICT  108  190  400   400   21733      15764       2     ""                                 255 255 255 
9   PICT  096  223  400   400   37498      14513       3     ""                                 255 255 255 
10  PICT  126  215  400   400   52012      15162       4     ""                                 255 255 255 

17  SND   0    0    0     0     4         00000       0     "xc1s4end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         67175       0     ""  0 0 0      

