ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  220  110  380   500    00000     07151        3     "They have called Barbarossa the scourge of Europe. But he was as skilled a diplomat as he was a warrior."     0   0   0
2  TEXT  155  120  520   500    07151     19798       3     "He united Germany with more than just the sword. He established a set of legal codes known as the Land Peaces. He helped the hungry by fixing an official price for grain after every harvest. The provinces of Germany quickly became the wealthiest and most powerful in Europe."     0   0   0
3  TEXT  350  150  330   500    26950     08216        3     "The Holy Roman Empire was so successful, in fact, that it quickly overgrew its boundaries."     0   0   0

4   PICT  146  110   400   400    00000    07151        0     ""                                 255 255 255
5   PICT  107  232   400   400    07151    19798       1     ""                                 255 255 255
6   PICT  102  196   400   400    26950    08216        2     ""                                 255 255 255


18 WND    0    0    0     0      0   35166   0  ""  0 0 0      



15  SND   0    0    0     0      0000      15000       0     "c4s1end.mp3"                     0   0   0 

