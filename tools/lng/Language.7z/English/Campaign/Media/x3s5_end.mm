ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  141  120  450   168    00000      17925       3     "I hoped that the surviving Spanish on the edge of the lake could see as their captured comrades were dragged up the steps of the great pyramid.  Perhaps they would then understand why we feared the wrath of the feathered serpent, Quetzalcoatl.  Perhaps they would know fear as well."     12 9 4   
2   TEXT  480  200  200   300    17925      15359       3     "With the fighting subsided, there was much work to be done.  Our city had suffered much from the Spanish occupation and the fighting in the streets.  The priests set out repairing the temples, for the Spanish had cast down the idols that we had placed there."     12 9 4   
3   TEXT  241  120  350   168    33285      12411       3     "We began a celebration to give thanks to the gods when a great plague struck Tenochtitlan.  Many of our people became helpless and could only lie on their beds.  Many others died."     12 9 4   
4   TEXT  341  250  350   168    45696      22058       3     "We did not know if the gods were still unhappy with us, or if this was some weapon unleashed by the Spanish.  Regardless, if Cort�z returned, he would find a much weakened city.  I could not let that happen.  So says Cuauhtemoc, Emperor of Tenochtitlan."     12 9 4   

5   PICT  383  175  400   400   00000      17925       0     ""                                 255 255 255 
6   PICT  109  153  400   400   17925      15359       1     ""                                 255 255 255 
7   PICT  274  259  400   400   33285      12411       2     ""                                 255 255 255 
8   PICT  159  145  400   400   45696      22058       3     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc3s5end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         67755      0     ""  0 0 0      

