ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  110  080  590   88    00000     18575       3     "Much of the Viking history is recorded in oral accounts called sagas passed down through generations.  The most famous sagas are reserved for the adventures of Erik the Red and his men who crossed the mighty sea in tiny ships to forge a new Viking sovereignty."     0   0   0   
2   TEXT  100  085  590   80    18575     17182       3     "Vinland, as the new world was called, was not kind to the Vikings.  Though they lacked the iron weapons of the Norsemen, the native Skraelings were fierce warriors, and fought relentlessly to defend their homeland against the Norse invaders.  "     0   0   0   
3   TEXT  100  110  550   70     35758     13421       3     "The vastness of the North Atlantic cut off the Vikings in Newfoundland from their homeland, and they suffered many long years in trying to establish their new colony."     0   0   0   


4   PICT  272  167  400   400   00000      35758       0     ""                                 255 255 255 
5   PICT  214  176  400   400   35758      13421       1     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s2end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         49179       0     ""  0 0 0      

