ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  120  220  250   188    00000      19619      3     "Harold the Saxon�s huskarls looked certain to defend the crown for him as they fought the Vikings to a bloody stalemate at Stamford Bridge.  Despite his losses, Harold marched his exhausted troops south to meet William the Conqueror near Hastings."     0   0   0   
2   TEXT  120  220  250   188    19619      16975       3     "William�s archers and pikemen were no match for Harold the Saxon�s veteran huskarls.  Harold even broke the charge of William�s knights.  William himself went down in the fray and as rumors of his death spread, the Normans turned to flee.  "     0   0   0   
3   TEXT  350  240  320   178    36594      23219       3     "But William was not dead, and he rallied his troops by throwing aside his helmet so they could see his clean-shaven face and know he was alive.  William and his armored knights rode down the huskarls, breaking the Saxon force, and continued their ride all the way to London. William was crowned king on Christmas Day."     0   0   0   
4   TEXT  350  240  320   178    59814      15522       3     "Because his reign eventually ushered England into a position of unprecedented world leadership, the year 1066 became established as the most famous date in English history."     0   0   0   




5   PICT  383  183  400   400   00000      36594       0     ""    0 0 0
6   PICT  122  124  400   400   36594      38742       1     ""    0 0 0                             255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s3end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         75337       0     ""  0 0 0      

