ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  255  085  350   200    00000     12074        3     "The Cid was in exile again, and this time there were no Moors to welcome him in.  He wandered the bleak rocks of Castille and wondered if his tale was finally at an end.  "    12  9  4 
2   TEXT  255  085  350   200    12074     22807        3     "And yet, a remarkable thing happened.  Many mercenaries and knights knew of the tales of the Cid, and were eager to follow him, even without a castle.  As the Cid wandered further south, more men, Christian and Moslem, joined his army.  Eventually, the Cid had a large enough force to carve out a fiefdom of his own."    12  9  4 
3   TEXT  255  445  350   200    34881     08863        3     "King Alfonso had set his sights on beautiful Valencia, the jewel of the Moorish coast.  But the Cid was closer and could get there sooner."    12  9  4 
4   TEXT  240  085  350   200    43744     12794        3     "If he conquered Valencia, the Cid would have protection not only from the machinations of Alfonso, but also a bulwark against the inevitable second invasion of Yusuf and the Berbers."    12  9  4 
5   TEXT  125  200  250   200    56539     11367        3     "Events would have unfolded simply then, had not our old enemy, Count Berenguer of Barcelona, picked that moment to strike back at the Cid."    12  9  4 

6   PICT  161  205  400   400    00000     12074        0     "" 0 0 0
7   PICT  135  256  400   400    12074     22807        1     "" 0 0 0
8   PICT  141  089  400   400    34881     08863        2     "" 0 0 0
9   PICT  167  157  400   400    43744     12794        3     "" 0 0 0
10  PICT  379  128  400   400    56539     11367        4     "" 0 0 0


16  SND   0    0    0     0      4          1000        0     "xc2s5.mp3" 0 0 0 

17  WND   0    0    0     0      0          67906        0     "" 0 0 0      
