ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  180  140  450   168    00000      21733       3     "The soul of the Frankish army was its knights, but Charles Martel knew that his cavalry -- undisciplined, buried under weight of weapons and armor -- could not match the swiftness of the Moslem riders.  Therefore, he ordered the knights to dismount and join ranks with the Frankish swordsmen to form a tight shield wall."     0   0   0   
2   TEXT  180  140  450   168    21733      17832       3     "The Moslems had always conquered with swift offensiveness and were not equipped to counter the Franks� defensive strategy.  The arrows of the Moslem archers bounced harmlessly off the heavy Frankish armor, and the light Moslem cavalry could not breach the human chain."     0   0   0   
3   TEXT  400  220  300   400    39566      57730       3     "Battered and bleeding, the Moslems broke ranks and fled back to the Pyrenees and the protection of Spain.  From Charles Martel�s Frankish kingdom, eventually grew the Holy Roman Empire, making him the founding father of both Germany and France."     0   0   0   

4   PICT  193  338  400   400   00000      39566       0     ""                                 255 255 255 
5   PICT  110  064  400   400   39566      57730       1     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s1end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         57730       0     ""  0 0 0      

