ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204   085   475    60    0000      5504        0     "The time for minor skirmishes is over. We now prepare for war."     66 57 20
2   TEXT  204   100   475    60    5504      9910        0     "The villain, Longshanks, is poised to cross the River Forth and threaten the town of Stirling with a force of men-at-arms, heavy cavalry, and a multitude of archers."     66 57 20
3   TEXT  204   420   475    60    15415     13424       0     "Our newly forged army marches southward, to establish our own base and attack the English before they can ready their troops."     66 57 20

4   PICT  119   108   400   400    0000      5504        0     ""                                 255 255 255 
5   PICT  119   158   400   400    5504      9910        1     ""                                 255 255 255 
6   PICT  85     50   400   400    15415     13424       2     ""                                 255 255 255 

7   SND     0     0     0     0       0      28839       0     "c8s5.mp3"                        0   0   0 

8   WND     0     0     0     0       0      28839       0     ""        0 0 0      
