ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
1   TEXT  170  414  528   130    00000    15321       2     "Once I was amazed at the nobility of the Saracen warriors. Only a few years ago they entered battle as gentlemen, bringing with them treasure chests, wine, singing girls, and collections of doves, nightingales, and parrots. No longer. "     0   0   0   
2   TEXT  152  405  546   126    15321    18022       2     "In reaction to European hostility and fanaticism, the Saracens have steadily become more resolute � more bloodthirsty. Their love of art is replaced by a love for battle. Now, in answer to the Crusade, they have adapted their principle of jihad for warfare."     0   0   0   
3   TEXT  146  268  496   82     33343    18715       2     "The result has been devastating to the Crusaders. The European presence in the Holy Land was finished. Or so everyone believed �"     0   0   0   


8   PICT  127   88   400   400    00000      15321        0     ""                                 255 255 255 
9   PICT  103   88   400   400    15321      18022       1     ""                                 255 255 255 
10  PICT  103   129  400   400    33343      18715      2     ""                                 255 255 255 

17  SND   0    0    0     0      4   0000           0     "c2s5end.mp3"                        0   0   0 
18 WND    0    0    0     0      0    52059  0  ""  0 0 0      

