ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  354  119  324   300    00000   12128        4     "European knights fight as individuals, but Mongols fight as part of a united army. Laden down with armor, the Polish and Germans could not catch our quick-footed horses."     37 15 9 
1   TEXT  197  415  422   300    12128   09455       4     "Time and again we fired flaming arrows at them, then retreated out of range. When the enemy cavalry pursued, we would lead them into an ambush."     37 15 9 
2   TEXT  175  423  472   300    21584   10819       4     "The ambush was always announced by the naqara, a huge drum carried into battle on a camel. A hundred times a hundred times has the naqara sounded on this day."     37 15 9 
3   TEXT  193  399  440   300    32403   15452       4     "We were ordered to cut off an ear for every victim. Nine sacks of ears were sent back to Ogatai Khan."     37 15 9 




4   PICT  095  172    400   400    00000     12128    0      ""                                 255 255 255 
5   PICT  105  084    400   400    12128     09455    1      ""                                 255 255 255 
6   PICT  293  093    400   400    21584     10819    2      ""                                 255 255 255 
7   PICT  138  101    400   400    32403     15452    3      ""                                 255 255 255 



17  SND   0    0    0     0      4         0000           0     "c3s5end.mp3"                        0   0   0 

18 WND    0    0    0     0      0   47856     0  ""  0 0 0      

