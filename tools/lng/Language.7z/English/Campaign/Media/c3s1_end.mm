ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0   TEXT  127  110   552   300    00000      09752        4     "Nearly all of the Mongol tribes have united under the Great Khan. The chieftains of those tribes reluctant to join were boiled alive."     37 15 9
1   TEXT  420  200   250   300    09752      14117        4     "Each day new faces have taken up the bow; unfamiliar hands hold the Nine Bands of yak hair that has become Genghis's standard. There are more men and horses gathered in the camp than I ever knew existed."     37 15 9
2   TEXT  176  106   464   300    23870      23405        4     "Horse archers and lancers, men in leather cuirass and silk armor, all lift their heads upward to the platform from where Genghis speaks. The Great Khan calls himself the punishment of God. Men smile like hungry wolves. It is dawn of the first day of the Mongolian Empire."     37 15 9

3   PICT  285  178   400   400    00000       09752    0      ""                                 255 255 255 
4   PICT   97   93   400   400    09752       14117    1      ""                                 255 255 255 
5   PICT  147  227   400   400    23870       23405    2      ""                                 255 255 255 




17  SND   0    0    0     0      4         0000           0     "c3s1end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   47275    0  ""  0 0 0      

