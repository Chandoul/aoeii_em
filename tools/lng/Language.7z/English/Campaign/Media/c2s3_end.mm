ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  148  103  444   200    00000      06455        2     "The fighting was fierce � the Crusaders had to conquer or die. Mostly, they died."     0   0   0   
2   TEXT  166  405  496   122    06455      15205        2     "Saladin has treated his prisoners well, providing them with icewater from the mountains and comfortable tents. For the first time in years, I have been able to speak to fellow countrymen. But I am unsure what to say to these...invaders."     0   0   0   
3   TEXT  172  373  506   174    21660      19462        2     "Not all of the prisoners were treated so royally. Reynald de Chatillon was captured here and, fulfilling his vow, Saladin sliced off Reynald's head with his own scimitar. How ironic that it was only after the Crusaders entered their lands that the Saracens were transformed into the people that we set out to destroy."     0   0   0   



8   PICT  387   165  400   400    00000    06455     0     ""                                 255 255 255 
9   PICT  102   75   400   400    06455    15205     1     ""                                 255 255 255 
10   PICT  112   91   400   400    21660    19462     2     ""                                 255 255 255 


17  SND   0    0    0     0      4         0000           0     "c2s3end.mp3"                        0   0   0 
18 WND    0    0    0     0      0  41122   0  ""  0 0 0      

