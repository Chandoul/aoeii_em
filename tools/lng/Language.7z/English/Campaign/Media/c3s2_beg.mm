ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0  TEXT  175  424  466  094    00000      15097        4     "Winter has come to the steppes. The earth is frozen hard as bone, and the only movement is steam rising from the nostrils of men and horses. Only the promise of battle brings warmth."     37 15 9
1  TEXT  288  100  410  150    15097      17596        4     "Nearly all the tribes in Mongolia now answer to Genghis Khan. But with success, comes enemies. A man named Kushluk has challenged Genghis's right to rule. Kushluk sows discord among the Kara-Khitai tribe and means to have himself proclaimed as a rival Khan."     37 15 9
2  TEXT  130  450  560  076    32693      18483        4     "Genghis cannot allow these transgressions to go unpunished. He needs to set an example. So we ride west, to find and slay Kushluk. If the Kara-Khitai shelter him, then their lives are forfeit as well."     37 15 9


14   PICT  110   84    400   400    00000     15097        0     ""                                 255 255 255
15   PICT  61    172   400   400    15097     17596        1     ""                                 255 255 255
16   PICT  173   79    400   400    32693     18483        2     ""                                 255 255 255



18 WND    0    0    0     0      0   51176     0  ""  0 0 0      

19  SND   0    0    0     0      0000      15000       0     "c3s2.mp3"                     0   0   0 

