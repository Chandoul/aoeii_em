ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  190  085  450   400    00000      20712       3     "Although the Cid defeated Alfonso�s army in combat, the sly king knew there were more devious ways to win a war.  Alfonso lured his brother, King Sancho, to a secret conference below the city walls of Zamora, and had him assassinated in the night."     0   0   0   
2   TEXT  160  220  200   200    20712      07801       3     "With the death of his brother, Alfonso became king of both Leon and Castille -- the most powerful king in Christian Spain."     0   0   0   
3   TEXT  220  085  450   130    28514      07987       3     "The Cid could not trust King Alfonso, yet he was sworn to serve his king, and that man was now Alfonso."     0   0   0   
4   TEXT  250  085  400   130    36501      20340       3     "The Cid forced King Alfonso to swear an oath upon sacred relics that he had nothing to do with Sancho�s death.  Before his army and his court, a nervous Alfonso did make this declaration.  In so doing, the Cid helped to cement Alfonso�s claim as King in the hearts of the people, for they so trusted the Cid."     0   0   0   
5   TEXT  170  400  500   300    56842      29942       3     "King Alfonso did not recognize that the Cid had done him a service.  Instead, Alfonso held a grudge against the man who was the greatest of his knights for ever doubting him.  Alfonso also was jealous and suspicious of the Cid�s popularity with the soldiers and the common man.  He sent the Cid into dangerous battle again and again, but always the Cid emerged victorious."     0   0   0   


6   PICT  223  177   400   400   00000      20712       0     ""                                 255 255 255 
7   PICT  293  074   400   400   20712      07801       1     ""                                 255 255 255 
8   PICT  291  157   400   400   28514      07987       2     ""                                 255 255 255 
9   PICT  118  206   400   400   36501      20340        3     ""                                 255 255 255 
10  PICT  255  069   400   400   56842      29942        4     ""                                 255 255 255 


17  SND   0    0    0     0     4         00000       0     "xc2s1end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         86784       0     ""  0 0 0      

