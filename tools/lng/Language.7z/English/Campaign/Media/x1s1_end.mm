ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  430  100  250   200    00000       09287       4     "I asked Father Armand more about this legendary Attila the Hun, whom the stories always treat as more of a monster than a man."     0   0   0   
2   TEXT  380  085  300   165    09287       17089       4     "�He was a man,� the priest said, �but he did not look like the Romans, nor did he worship the Roman god.  That was the cause of all that was to follow.�  Father Armand shivered as if from the cold breeze that blew in from the chapel�s open windows.  "     0   0   0   
3   TEXT  310  080  350   175    26377       28075       4    "'Kingship among the barbarians was not by divine right or lineage, but by who had the strongest will.  Attila was the strongest of the Huns, and he reinforced his position by brandishing a rusty old blade and proclaiming it to be the Sword of Mars, the old Roman god of war. Attila had a custom of fiercely rolling his eyes, as if he wished to enjoy the terror which he inspired....'"     0   0   0   
4   TEXT  110  100  350   200    54453       30670       4     "'He had a power over other men, so that many chose to join him.  Many foreigners joined his council, Scythians and Burgundians and Goths.  Most notable among these was the son of a prominent Roman family sent as a hostage to ensure peace between Romans and Huns.  The name of this boy was Flavius Aetius, a name not soon to be forgotten.�"     0   0   0   

5   PICT  117  092  400   400   00000      09287       0     ""                                 255 255 255 
6   PICT  060  083  400   400   09287      45165       1     ""                                 255 255 255 
7   PICT  183  133  400   400   54453      30670       2     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc1s1end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         85124       0     ""  0 0 0      

