ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  220   100  475    400    0000      12312       0     "Longshanks has invaded, stormed, and sacked the city of Perth. Worse, he has captured the fabled Stone of Scone and declared himself King of Scotland."     66 57 20
2   TEXT  440   256   280    400    12312     16927       0     "If we cannot bring about a victory in battle soon, then the Scottish armies will be too demoralized to put up any fight at all. If this mythical Scottish giant does exist, I wish that he would get his forces up to Stirling, where we shall next do battle."     66 57 20

3   PICT  276   169   400   400    0000      12312       0     ""                                 255 255 255 
4   PICT  135    98   400   400    12312     16927       1     ""                                 255 255 255 

5   SND     0     0     0     0       0     29239        0     "c8s4end.mp3"                        0   0   0 

6   WND     0     0     0     0       0     29239        0     ""        0 0 0      
