ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204   100   475    400    0000       12051      0     "It looked certain that we would be defeated at Falkirk. Yet somehow, though outnumbered and outranged by English longbows, we were victorious."     66 57 20
2   TEXT  204   100   475    400    12051      8324       0     "The English castle was torn down and a Scottish one will be built in its place."     66 57 20
3   TEXT  100   246   300    400   20375      12837      0     "William Wallace has shown us the path to victory. Although he is but one man, he inspires great deeds in others and many of the Scottish princes and lords have drawn their swords with his."     66 57 20
4   TEXT  340   200   300    400   33212      7120       0     "Wallace's own sword is a five-and-a-half-foot beast, forged of course in Scotland."     66 57 20
5   TEXT  204   430   475    400   40333      19417      0     "He has sworn not to rest, until his sword finds the neck of Edward Longshanks.  The struggle will continue, but we have learned the ways of war. Now it is the English who will know fear."     66 57 20

6   PICT  148   114   400   400    0000       12051      0     ""                                 255 255 255 
7   PICT  109   200   400   400    12051      8324       1     ""                                 255 255 255 
8   PICT  312   75    400   400    20375      12837      2     ""                                 255 255 255 
9   PICT  125   72    400   400    33212      7120       3     ""                                 255 255 255 
10  PICT  110   43    400   400    40333      19417      4     ""                                 255 255 255 

11  SND     0     0     0     0       0     59750        0     "c8s7end.mp3"                        0   0   0 

12  WND     0     0     0     0       0     59750        0     ""        0 0 0      
