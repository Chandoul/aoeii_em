ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  275  160  400   500    00000      15046        3     "In Rome, the pope firmly believed that it was the church, not the emperor, who was the ultimate authority for the empire. Barbarossa could not convince the pope to see things his way, so he appointed his own pope."     0   0   0
2  TEXT  250  455  330   500    15046      07430        3     "This too was not enough, for pope and antipope promptly excommunicated each other."     0   0   0
3  TEXT  145  145  400   500    22476      14095        3     "In the end, Barbarossa had to resort again to politics at the point of a lance. If the pope would not listen to reason, then perhaps he would concede with two thousand German knights pouring down the Italian peninsula."     0   0   0
4  TEXT  370  460  350   500    36572      09857        3     "The greatest of the northern cities, the virtual capital of Lombardy, was Milan. The lords of Milan were as proud as they were belligerent."     0   0   0
5  TEXT  165  250  200   500    46430      18666        3     "Barbarossa was determined to raze Milan to the ground as a warning to all the Italian city-states, and particularly the pope in Rome. The message was clear: He, Frederick Barbarossa, was the one and true Holy Roman Emperor."     0   0   0

6   PICT  50   33   400   400    00000      15046        0     ""                                 255 255 255
7   PICT  253  73   400   400    15046      07430        1     ""                                 255 255 255
8   PICT  117  82   400   400    22476      14095        2     ""                                 255 255 255
9   PICT  95   70   400   400    36572      09857        3     ""                                 255 255 255
10  PICT  357  46   400   400    46430      18666        4     ""                                 255 255 255

18 WND    0    0    0     0      0   65097   0  ""  0 0 0      



15  SND   0    0    0     0      0000      15000       0     "c4s3.mp3"                     0   0   0 

