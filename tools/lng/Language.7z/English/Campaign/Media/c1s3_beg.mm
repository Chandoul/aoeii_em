ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  339  299  144   0050   0000       02321        3    "June 14, Orl�ans"     0   0   0   
2   TEXT  272  426  306   400    02321      09044        3    "Our rescue of Orl�ans was a setback for our enemies, but only a minor one. The British still possess half of France." 0   0   0 
3   TEXT  251  153  308   600    11366      06202        3    "Tragically, we have cooled our heels for weeks while the Dauphin's advisors debate."      0   0   0
4   TEXT  196  274  266   400    17569      08727        3    "Joan became irritated with the delay and reassembled her army. She talks of nothing but her mission to drive the British into the sea."  0 0 0 
5   TEXT  418  380  296   500    26296      09927        3    "The force of Joan's will is titanic. She has gathered to her banner swearing brigands and knaves and turned them into patriots and heroes."     0   0   0  
6   TEXT  372  180  324   500    36223      12697        3    "Among them is the man La Hire. A giant clad in plate mail; he drives men on with curses and fists. There will be plenty of British necks for La Hire to break at Patay."     0   0   0  
7   TEXT  228  162  396   500    48920      12362        3    "Patay is the gateway to the Loire River Valley.  The British hold the Loire in a grip of steel, whilst a huge army under Sir John Fastolf devastates the countryside."     0   0   0 
8   TEXT  350  130  366   500    61282      14391        3    "Joan leads us to Patay to capture the British castles. However we must avoid Fastolf's army 'til we are strong enough to face his veterans."     0   0   0 

9    PICT  222 81    400   400    02321      09044       0     ""                                 255 255 255 
10   PICT  210 240   400   400    11366      06202       1     ""                                 255 255 255 
11   PICT  446 117   400   400    17569      08727       2     ""                                 255 255 255 
12   PICT  94  87    400   400    26296      09927       3     ""                                 255 255 255 
13   PICT  154 141   400   400    36223      12697       4     ""                                 255 255 255 
14   PICT  162 306   400   400    48920      12362       5     ""                                 255 255 255 
15   PICT  093 092   400   400    61282      14391       6     ""                                 255 255 255 

16  SND   0    0    0     0      0000         1000           0     "c1s3.mp3"                        0   0   0 
17  WND    0    0    0     0      0   75673   0  ""  0 0 0      

