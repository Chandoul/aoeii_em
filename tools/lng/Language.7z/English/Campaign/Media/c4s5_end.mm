ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  280  106  400   500    00000      24138        3     "Barbarossa's weary army had marched for hundreds of miles through the cracked mountains in the heat of July. So when it stumbled upon the G�ksu River, the men were astonished and grateful. Barbarossa himself could not resist plunging into the cold water without even pausing to remove his armor."     0   0   0
2  TEXT  170  183  520   500    24138      05583       3     "To the disbelief of the surviving troops, Barbarossa drowned."     0   0   0
3  TEXT  155  120  520   500    29721      21675        3     "Some said the emperor could not swim in his plate armor. Others believed the sixty-seven-year-old heart had finally given out. Regardless of the exact cause of death, Barbarossa's Crusade ended there, on June 10, 1190. The Holy Roman Emperor was gone."     0   0   0

4   PICT  131  122   400   400    00000      24138        0     ""                                 255 255 255
5   PICT  111  153   400   400    24138      05583       1     ""                                 255 255 255
6   PICT  59   226   400   400    29721      21675        2     ""                                 255 255 255

18 WND    0    0    0     0      0   51397   0  ""  0 0 0      

15  SND   0    0    0     0      0000      15000       0     "c4s5end.mp3"                     0   0   0 

