ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  460  200  225   400    00000     19964       3     "Once again, the Cid emerged victorious, and delivered the city to King Alfonso.  Moor and Christian alike shouted his name from the city walls, and named him El Cid Campeador -- my lord, the conqueror.  After nearly 400 years of Moorish rule, the city of Toledo was ruled by a Christian king."     0   0   0   
2   TEXT  210  085  430   200    19964     21442       3     "But still Alfonso was not satisfied!  He accused the Cid of seeking personal glory at the expense of the crown.  When he heard the peasants shouting the name of the Cid instead of Alfonso�s own name, he became even more angered.  I knew then that our contented lives in Castille were about to end."     0   0   0   




3   PICT  119  077  400   400   00000      19964       0     ""                                 255 255 255 
4   PICT  248  208  400   400   19964      21442       1     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc2s2end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         41406       0     ""  0 0 0      

