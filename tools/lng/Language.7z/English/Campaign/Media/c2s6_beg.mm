ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  200  306  450   60     00000      05381      2    "The City of Acre. Nearly twenty-one years have I ridden with Saladin �"     0   0   0   
2   TEXT  129  103  584   122    05381      15980      2    "When word of the Saracen victory at Jerusalem reached Europe, another Crusade was launched. The kings of the three most powerful nations in Europe � England, France, and the Holy Roman Empire � embarked for the Holy Land with hundreds of thousands of troops."     0   0   0   
3   TEXT  380  380  338   148    21362      09659      2    "Saladin knows that his most dangerous opponent is Richard the Lionhearted of England, a brilliant tactician who learned the art of war fighting against his own father."     0   0   0   
4   TEXT  140  105   420   68     31021      07247      2    "He builds colossal fortresses and fights always from the front lines � the ideal of a romantic warrior."     0   0   0   
5   TEXT  171  95   496   150   38269      15723      2    "Richard's army has come ashore near Acre. Much of Saladin's army is trapped in the city, while two monstrous English trebuchets pound at Acre's walls. If Richard can defeat our army here, then he can walk into Jerusalem unopposed."     0   0   0   
6   TEXT  476  193   232   222   53992      11208      2    "Saladin knows that this is the climax of his jihad. All the Crusader states have fallen. If the Saracens can hold onto Acre, then the Europeans will be forced to return home."     0   0   0   
7   TEXT  476  193   200   198   65201      11354      2    "If Acre falls, then the centuries-long nightmare of eternal war, raid and counterraid, begin again. All Saladin's victories will be for nothing."     0   0   0   




8   PICT  102   227  400   400    05381    15980     0    ""                                 255 255 255 
9   PICT  132   102  400   400    21362    09659      1    ""  255 255 255
10   PICT  265   171  400   400   31021    03715     2    ""  255 255 255
11   PICT  277   202  400   400   34737    03532     3    ""  255 255 255
12   PICT  103   180  400   400   38269    15723     4    ""  255 255 255
13   PICT  106   85  400   400    53992    22563     5    ""  255 255 255

17  SND   0    0    0     0      0000       1000        0    "c2s6.mp3"                         0   0   0 
18 WND    0    0    0     0      0   76556  0  ""  0 0 0      
