ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  145  115  550   500    0000       11476       3     "Barbarossa was not kind to the Milanese. In response to one attempt at negotiations during the siege, he sent six Italians marching back to the city."     0   0   0
2  TEXT  250  140  350   500    11476      07150       3     "Five had been blinded, but the sixth only had his nose cut off so that he could lead the other five."     0   0   0
3  TEXT  265  120  320   500    18627      19825       3     "Northern Italy had been mercilessly conquered and placed under Imperial governance. But Italy would not submit. If anything, the destruction of Milan made the Italian cities even more incensed at their would-be emperor."     0   0   0

4   PICT  94   174   400   400    00000      11476      0     ""                                 255 255 255
5   PICT  106  127   400   400    11476      07150      1     ""                                 255 255 255
6   PICT  115  083   400   400    18627      19825      2     ""                                 255 255 255

18 WND    0    0    0     0      0   38452   0  ""  0 0 0      

15  SND   0    0    0     0      1000      15000       0     "c4s3end.mp3"                     0   0   0 

