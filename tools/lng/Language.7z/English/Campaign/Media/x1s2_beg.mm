ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  200  200   200    00000     15603        3     "Now that the memories had stirred, Father Armand seemed eager to tell his tale.  He explained how the Huns, like the other barbarians, had a style of warfare dramatically different from the ancient Romans or my own Franks.  " 12  9  4 
2   TEXT  470  180  200   300    15603     21269        3     "The Huns would charge as one group, often firing arrows as they came, and then suddenly retreat again.  For the nations of Europe, who were used to forming up lines and columns and even issuing challenges for personal combat, this was an aberration.  They were unable to comprehend warfare in this manner." 12  9  4 
3   TEXT  160  095  300   200    36873     14210        3     "Barbarians did not conquer lands.  They did not try and hold and colonize the cities they attacked.  Instead, they ravaged and pillaged, and took their loot back to their camps." 12  9  4 
4   TEXT  410  100  300   200    51083     20723        3     "By that time, there were two Roman Empires, the government having decided that the Roman lands were simply too vast for one city to manage effectively.  Attila and the Huns began a series of raids into the Eastern Empire." 12  9  4 


5   PICT  345  119  400   400    00000     15603        0     "" 0 0 0
6   PICT  042  101  400   400    15603     21269        1     "" 0 0 0
7   PICT  198  100 400   400     36873     14210        2     "" 0 0 0
8   PICT  135  229 400   400     51083     20723       3     "" 0 0 0



16  SND   0    0    0     0      4          1000        0     "xc1s2.mp3" 0 0 0 

17  WND   0    0    0     0      0          71807        0     "" 0 0 0      
