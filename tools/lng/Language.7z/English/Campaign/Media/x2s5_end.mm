ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  235  085  400   200    00000      13485       3     "How abundant the orange groves and olive trees seemed to the conquerors who had come from bleak Castille.  Valencia was a tropical paradise, complete with palm trees, a silk market and abundant fish and waterfowl."     0   0   0   
2   TEXT  235  085  400   300    13485      13728       3     "After the Cid had secured the castle and saw to the defenses of the city, he sent for me and the children.  Our reunion took place on the highest tower of the castle, before a sea that consumed the entire horizon."     0   0   0   
3   TEXT  255  085  350   300    27213      10866       3     "We turned Valencia into our own kingdom, uniting eight-thousand Christian and twenty-thousand Moorish soldiers.  It was the greatest of the Cid�s accomplishments to date."     0   0   0   
4   TEXT  140  200  200   400    38080      15696       3     "We were far away from the reach of King Alfonso, and Count Berenguer himself was safely locked in Valencia�s dungeons.  In time, he would be ransomed, and one of our daughters married to his nephew and heir, to ward against future conflicts."     0   0   0   
5   TEXT  140  200  200   400    53777      16079       3     "If only the tale of the Cid had ended there, beneath the Valencian sunsets.  But it was not to be. Valencia lay right in the path of the advancing horde of frenzied Yusuf and his Berber hordes."     0   0   0   




6   PICT  178  272  400   400   00000      13485       0     ""                                 255 255 255 
7   PICT  246  265  400   400   13485      13728       1     ""                                 255 255 255 
8   PICT  319  170  400   400   27213      10866       2     ""                                 255 255 255 
9   PICT  379  079  400   400   38080      15696       3     ""                                 255 255 255 
10  PICT  350  074  400   400   53777      16079       4     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc2s5end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         69857       0     ""  0 0 0      

