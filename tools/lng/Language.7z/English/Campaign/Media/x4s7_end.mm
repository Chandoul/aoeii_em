ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  200  360  450   168    00000      22528       3     "Kyoto paid dearly for Nobunaga�s death and in the end, Hideyoshi was able to accomplish what his mentor could not -- by 1590, Japan was a unified country.  Great though it was, this accomplishment did not satisfy Hideyoshi, who then set about on an ambitious plan to conquer China and Korea."     0   0   0   
2   TEXT  400  250  350   268    22528      23006       3     "Japan was not free of conflict, as civil wars continued to rise and fall for many years.  However, the Ieyasu family, former allies of Hideyoshi, continued to rule Japan as Shogun until the 19th century."     0   0   0   

3   PICT  136  064  400   400   00000      22528       0     ""                                 255 255 255 
4   PICT  134  066  400   400   22528      23006       1     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s7end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         45534       0     ""  0 0 0      

