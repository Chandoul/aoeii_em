ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  140  150  220   160    00000    13404        3     "Tragedy. As the refugees fled into the Ch�teau of Compiegne, Joan was trapped outside. Burgundian soldiers knocked her from her horse and paraded around with their prisoner."     0   0   0   
2   TEXT  415  283  284   300    13404    07015        3     "None of us can sleep, knowing our precious Joan of Arc languishes in a Burgundian prison."     0   0   0   
3   TEXT  145  120  242   300    20420    11598        3     "The soldiers stare at the uncaring sky, condemning themselves for being unable to save her�for being unable to save France."     0   0   0   
4   TEXT  135  100  242   300    32018    17022        3     "Paris was the first major defeat ever dealt to our army. Had the King sent the promised reinforcements, we would have captured the city. Now, it is France's darkest hour."     0   0   0   


7   PICT  337   080   400   400    00000      13404        0     ""                                 255 255 255 
8   PICT  136   092   400   400    13404      07015        1     ""                                 255 255 255 
9   PICT  331  058   400  400     20420      11598        2      ""                                 255 255 255 
10   PICT  349  191  400  400     32018      17022        3      ""         255 255 255


17  SND   0    0    0     0      0000       1000        0    "c1s5end.mp3"                         0   0   0 

18 WND    0    0    0     0      0          49040       0    ""  0 0 0      

