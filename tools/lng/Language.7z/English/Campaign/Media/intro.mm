ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   PICT  0 0         400   400    0         07881        0     ""                                 255 255 255 
2   PICT  0 0         400   400    07881     04407        1     ""                                 255 255 255 
3   PICT  0 0         400   400    12288     04890       2     ""                                 255 255 255 
4   PICT  0 0         400   400    17179     05884        3     ""                                 255 255 255 
5   PICT  0 0         400   400    23064     04846        4     ""                                 255 255 255 
6   PICT  0 0         400   400    27911     04875        5     ""                                 255 255 255 
7   PICT  0 0         400   400    32786     04829        6     ""                                 255 255 255 
8   PICT  0 0         400   400    37616     08452        7     ""                                 255 255 255 
9   PICT  0 0         400   400    46068     06489        0     ""                                 255 255 255 

17  SND     0     0     0     0       4      0000        0     "intro.mp3"                        0   0   0 

18 WND      0     0     0     0       0     55000       0     ""        0 0 0      
