ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  110  110  425	  168    00000      21176       3     "In the gloom, the longhouse feels empty.  But it is filled with the odors of rust and tar and animal fur, and the snoring of dogs.  It is the man named Erik who speaks, smacking scarred fingers together for emphasis, the steam of his breath tangling with the wood smoke.  "     0   0   0   
2   TEXT  110  110  425   168    21176      24334       3     "He fills the men�s heads with legends of exploration and raiding, of a sea that eats longboats and an undiscovered country ripe for Viking occupation.  He tells the Vikings that they can leave their frigid homeland, and sail across the endless Sea of Worms to a new world brimming with wild grain and grapes and tall trees."     0   0   0  
3   TEXT  250  120  400   200    45511      19574       3     "To the Vikings, he speaks of paradise, and of course the grizzled Norse men are always eager for adventure.  When he asks for volunteers, men slam their weapons on tables and shout his name in the cold air.  Erik the Red smiles."     0   0   0  


4   PICT  316  116  400   400   00000      45511       0     ""                                 255 255 255 
5   PICT  182  300  400   400   45511      19574       1     ""              255 255 255 


15  SND   0    0    0     0     4         00000       0     "xc4s2.mp3"                        0   0   0 
16  WND   0    0    0     0     0         65085       0     ""  0 0 0      

