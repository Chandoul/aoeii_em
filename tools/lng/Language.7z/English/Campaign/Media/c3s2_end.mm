ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0   TEXT  164  157  336   134    00000      11935       4     "Genghis Khan knows that there are weapons aside from the lance and bow. He is a master of mental warfare. Just as he has made an example of Kushluk, he makes examples of enemy lands."     37 15 9
1   TEXT  140  110  524   098    11935      15674       4     "When first we encounter a new adversary, the Great Khan spares no one. We ride to the closest town, slay every living thing, burn down the city, sow the fields with salt, and make a mountain of enemy skulls."     37 15 9
2   TEXT  422  263  250   096    27609      12027       4     "After that, the other towns are quick to send forth their emissaries, eager to placate the ravenous Mongol hordes."     37 15 9


8   PICT  313  114   400   400    00000    11935       0     ""                                 255 255 255 
9   PICT  94   192   400   400    11935    15674       1     ""                                 255 255 255 
10   PICT  68   86    400   400    27609    12027       2     ""                                 255 255 255 



17  SND   0    0    0     0      4         0000           0     "c3s2end.mp3"                        0   0   0 

18 WND    0    0    0     0      0   39636   0  ""  0 0 0      

