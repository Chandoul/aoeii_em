ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  128  93   578   96     00000      16830        2     "The last time I entered Jerusalem, as a Crusading knight, I waded through the blood of victims. This time, not a building was looted, not a townsperson was injured. Saladin set free nearly every prisoner he took."     0   0   0   
2   TEXT  410  115  290   144    16830      18115        2     "The citizens of Jerusalem proclaimed Saladin as their savior. He offered to free me, but after 20 years in his service I have decided to see it out to the end."     0   0   0   


3   PICT  250   151   400   400   00000      16830        0     ""                                 255 255 255 
4   PICT  121   84   400   400    16830      18115        1     ""                                 255 255 255 

17  SND   0    0    0     0      4         0000           0     "c2s4end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   34946   0  ""  0 0 0      

