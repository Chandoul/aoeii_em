ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  339  299  400   0050   00000      03011       3    "September 3, Rheims"     0   0   0   
2   TEXT  209  191  408   0100   03011      09506       3    "France has a king once more. However, as Joan gains influence with the people, jealousy grows within the court."     0   0   0   
3   TEXT  209  191  408   0100   12517      09264       3    "The king's evil advisors now seek to destroy Joan. It is only a matter of time before they succeed in poisoning the king's mind."     0   0   0   
4   TEXT  196  393  440   0250   21782      25099       3    "Joan must hurry to fulfill her mission. Paris, the jewel of France, has been under English tyranny for decades, and French patriots trapped within the city are eager to escape. We are now marching on Paris, hoping that the reinforcements we have been promised will arrive in time."     0   0   0   


8   PICT  168   303  400   400    03011      18770      0    ""                                 255 255 255 
9   PICT  155  103  400   400     21782      25099      1    ""                                 255 255 255 

17  SND   0    0    0     0      0000       1000        0    "c1s5.mp3"                         0   0   0 
18 WND    0    0    0     0      0   46881   0  ""  0 0 0      
