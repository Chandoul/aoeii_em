ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  130  085  550   150   00000      34644       3     "The haze of spent gunpowder hangs over the gravel-strewn beach, confusing the seabirds that nest on the rocky outcroppings of Chinhae Bay.  As soon as the winds of the Eastern Sea disrupt the cloud, the Japanese navy will return, cannons blazing at the seawalls and what remains of the Korean fleet.  Although the army has so far managed to repel any of the samurai that have waded ashore, it is only a matter of time before the Japanese are victorious."     0   0   0   
2   TEXT  130  085  550   130   34644      41819       3     "The last hope for the Korean navy is an innovative commander named Yi Sun-shin.  Admiral Yi is constructing a secret weapon -- a ship with iron armor that can withstand the Japanese cannon and a spiked hull to repel boarders.  He calls these ships Kobukson, or Turtle Ships.  If Admiral Yi can ready his fleet of Turtle Ships in time, then the Koreans stand a chance of defeating the Japanese.  On the other hand, if he is too late�."     0   0   0   

3   PICT  125  153  400   400   00000      34644       0     ""                                 255 255 255 
4   PICT  122  187  400   400   34644      41819       1     ""                                 255 255 255 

15  SND   0    0    0     0     4         00000       0     "xc4s8.mp3"                        0   0   0 
16  WND   0    0    0     0     0         76463       0     ""  0 0 0      

