ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  170  306  600   60    00000       04417       2    "Tiberias, twenty and a half years of bloodshed �"     0   0   0   
2   TEXT  350  419  366   102   04417       06958       2    "We are far from the ocean, so the Saracens interpret the smell of salt and commotion of seabirds as signs from Heaven."     0   0   0   
3   TEXT  122  255  348   120   11375       10214       2    "I sit near Saladin's tent, watching the butchery below. Saracen horse archers sweep through yet another unorganized mob of European soldiers."     0   0   0   
4   TEXT  460  230  250   500   21590       14480       2    "The great Crusader nations have been reduced to puny city-states. Only Tiberias, Tyre, and Ascalon are still in Crusader hands. Nonetheless, these three cities are well fortified and could withstand any siege."     0   0   0   
5   TEXT  158  119  520   126   36071       15894       2    "Saladin has had many victories on the open desert, but the Crusader castles are unparalleled. If he is victorious now, the Holy Land will belong to the Saracens again. A failure could mean decades more of carnage."     0   0   0   

8   PICT  99   84    400   400    04417      06958      0    ""                                 255 255 255 
9   PICT  378  84    400   400    11375      10214      1    ""                                 255 255 255 
10  PICT  127  114   400   400    21590      14480      2     ""                                 255 255 255 
11  PICT  118  256   400   400    36071      15894      3     ""                                 255 255 255 


17  SND   0    0    0     0      0000       1000        0    "c2s5.mp3"                         0   0   0 
18 WND    0    0    0     0      0   51966   0  ""  0 0 0      
