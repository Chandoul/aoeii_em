ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  110  110  350   220    00000      21455       3     "The heavy Venetian galleases broke through the Turkish lines, and trampled over the smaller ships of the Turks.  But there were too few of the galleases to win the battle on their own.  The Spanish and Venetians attempted to grapple and board the Turkish ships, where the superior experience and weapons of the Christian marines could be brought to bear."     0   0   0   
2   TEXT  110  110  350   220    21455      17647       3     "As the day wore on, the Turkish juggernaut began to run out of steam.  Scores of Turkish galleys were dashed on the rocks and others sank to the bottom of the bay.  Less than fifty Turkish ships survived the battle."     0   0   0   
3   TEXT  100  110  350   220    39102      27933       3     "Lepanto was not the climax of the conflict between the Christians and the Turks on the Mediterranean, but it was a turning point.  The Turks had difficulty rebuilding their fleet back to its former size while the Christians continued to update their fleets with the latest technological advancements, insuring a decisive military advantage for further encounters on the high seas."     0   0   0   

4   PICT  310  197  400   400   00000      67036       0     ""                                 255 255 255 

17  SND   0    0    0     0     4         00000       0     "xc4s6end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         67036       0     ""  0 0 0      

