ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  191  100  450   150    00000      25913       3     "The Roman city of Naissus was erased from the earth.  The Huns so devastated the place that when the Roman ambassadors passed through to meet with Attila, they had to camp outside the city on the river. The riverbanks were covered with human bones, and the stench of death was so great that no one could enter the city. Many cities of Europe would soon suffer the same fate."    0   0   0   
2   TEXT  180  100  350   150    25913      05758       3     "The ambassadors that the Romans sent to Attila concealed an assassination attempt."    0   0   0   
3   TEXT  371  100  350   150    31672      12631       3     "Somehow, Attila knew of the attempt on his life, and sent the terrified assassin back to his Emperor, with the gold he had been paid to do the deed in a sack tied to his neck."    0   0   0   
4   TEXT  256  150  350   150    44303      14071       3     "Following such a demonstration, the Huns had no difficulty convincing the Eastern Roman Empire to start paying them a tribute, protection money to stave off the inevitable Hun invasion."    0   0   0   


5   PICT  119  214  400   400   00000      25913      0     ""                                 255 255 255 
6   PICT  298  082  400   400   25913      05758      1     ""                                 255 255 255 
7   PICT  014  165  400   400   31672      12631      2     ""                                 255 255 255 
8   PICT  231  273  400   400   44303      14071      3     ""                                 255 255 255 



17  SND   0    0    0     0     4         00000       0     "xc1s2end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         58374       0     ""  0 0 0      

