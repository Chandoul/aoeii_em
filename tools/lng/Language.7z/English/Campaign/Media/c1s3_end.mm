ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
1   TEXT  201  112  440   500    0000      15169        3     "After Patay, the myth of British invulnerability was dispelled. Now our army knows it is possible to win, but only if we are resolute and cunning."     0   0   0   
2   TEXT  300  264  250   500    15169     08329        3     "The British are a most deadly enemy, and their longbowmen time and again have decimated a charge of French knights."     0   0   0   
3   TEXT  346  200  360   100    23498     12661        3     "To make matters worse, we now face enemies on both sides. The Dauphin's advisors spend more and more time wrangling, jealous of Joan's influence at court."     0   0   0   
4   TEXT  246  145  360   075    36159     13461        3     "I pray that Joan can complete her divine mission before the Dauphin's envious advisors betray her."     0   0   0   

8   PICT  242  181   400   400     00000   15169        0    ""                                 255 255 255 
9   PICT  087  132   400   400    15169   08329        1    ""                                 255 255 255 
10  PICT  138   243   400   400    23498   26122        2    ""                                 255 255 255 

17  SND   0    0    0     0      4         0000           0     "c1s3end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   49621   0  ""  0 0 0      

