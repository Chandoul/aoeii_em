ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

0   TEXT  219  406  384    500     0000       13166        4     "A blue wolf took as his spouse a fallow doe. They settled at the head of the Onon River to raise their offspring. And there were born the Mongols."     37 15 9
1   TEXT  154  104  506    300     13116      12700        4     "So begins my life's work, 'The Secret History of the Mongols.' I have been selected to compose this epic because great events are about to take place. We are going to leave Mongolia."     37 15 9
2   TEXT  164  118  488    300     25816      18858        4     "I have lived always on this frigid, dry, and endless steppe. The tribes here squabble like vultures fighting over the desiccated corpse of a marmot. We fight over limited resources: scarce water, few trees, sparse grass for our herds to graze on."     37 15 9
3   TEXT  336  362  346    300     44675      18261        4     "A wise and dangerous man named Temuchin means to change all this. He says that if the tribal conflict is to end, the Mongols require but two things. First, we need green pastures for our herds. With more to go around, there will be less competition among the tribes."     37 15 9
4   TEXT  193  150  410    300     62937      06472       4     "Second, we are a nation of warriors; we need a common enemy with which to do battle."     37 15 9
5   TEXT  182  100  450    300     69409      09627         4     "To meet both these needs, Temuchin has come up with the most modest of schemes: to unite the tribes and go to war with anyone who stands in our path."     37 15 9
6   TEXT  138  128  318    300     79037      07809       4     "'How?' we ask him.  'How can nomadic horsemen in felt tents embark on a campaign of world conquest?' "     37 15 9
7   TEXT  367  133  266    300     86847      10556       4     "Temuchin replies that we will fight not as warriors, but as a unified army. We fight not for our glory, but for the glory of Mongolia.  "     37 15 9
8   TEXT  132  246  320    300     97403      13959       4     "And with those words, the name of Temuchin has passed almost into obscurity. His name is replaced with a title: Great Khan. Genghis Khan."     37 15 9   


14  PICT  158   85   400   400    0000      13116        0     "" 0 0 0
15  PICT  100   139  400   400    13116     12700        1     "" 0 0 0
16  PICT  205   208  400   400    25816     18858        2     "" 0 0 0
18  PICT  88    84   400   400    44675     18261         4     "" 0 0 0
17  PICT  277   241  400   400   62937      06472        3     "" 0 0 0
19  PICT  223   153  400   400    69409     09627       5     "" 0 0 0
20  PICT  327   101  400   400    79037     07809       6     "" 0 0 0
21  PICT  157   103  400   400    86847     10556       7     "" 0 0 0
22  PICT  418   113  400   400    97403     13959        8     "" 0 0 0



23  SND   0    0    0     0      4          0000        0     "c3s1.mp3" 0 0 0 
24  WND   0    0    0     0      0         111699        0     "" 0 0 0      
