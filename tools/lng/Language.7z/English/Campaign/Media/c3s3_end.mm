ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  205  143  438   500    00000      10545        4     "It was � a glorious slaughter. For years, visitors to China will be astounded by the mountain of human and horse skeletons that we have erected."     37 15 9   
1   TEXT  259  430  440   500    10545      10631        4     "The Hordes have gained one huge advantage by this invasion of China: technology. We now possess the knowledge and equipment to allow us to make siege weapons."     37 15 9
2   TEXT  239  161  386   500    21176      06411        4     "We will crack open the Persian and European castles to reach the softer parts within."     37 15 9
3   TEXT  153  144  485   500    27588      17876         4     "Genghis is pleased with our progress and with the legacy he leaves behind. His mother once ate wild onions and rodents to keep from starving. But the children and grandchildren of Genghis will eat off plates of Persian gold."     37 15 9



4 PICT  88    246   400   400    00000    10545        0    ""                                 255 255 255 
5 PICT  91    83    400   400    10545    10631       1    ""                                 255 255 255 
6 PICT  151   222   400   400    21176    06411       2    ""                                 255 255 255 
7 PICT  130   248   400   400    27588    17876        3    ""                                 255 255 255 




17  SND   0    0    0     0      4         0000           0     "c3s3end.mp3"                        0   0   0 

18 WND    0    0    0     0      0   45464     0  ""  0 0 0      

