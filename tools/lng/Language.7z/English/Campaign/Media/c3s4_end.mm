ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  180  124  462   300    00000      14860        4     "The Persian army numbered nearly half a million men but was beaten by a Mongol army less than half that size. The governors of outlying cities were executed by pouring molten silver into their eyes and throats."     37 15 9 
1   TEXT  130  394  558   300    14860      15610        4     "The capitol city of Samarkand, which was expected to withstand our siege for a year, fell in five days. Separate mountains were made of the skulls of men, women, children, horses, dogs, and cats."     37 15 9 
2   TEXT  101  136  598   300    30471      17231        4     "We roamed the streets in wonder at the opulence of the Persians, drinking at their fountains and gorging ourselves on sherbet and tropical fruit. For a man born in a tent, it seemed as if Genghis Khan had torn open the gates to Heaven itself."     37 15 9 
3   TEXT  183  441  454   300    47703      14978        4     "Russia and Mesopotamia were now ours to command. The empire now stretched over seven thousand miles from the Pacific Ocean to the Black Sea. We were about to enter Europe when tragedy struck."     37 15 9 



4   PICT  207  219    400   400    00000       14860     0      ""                                 255 255 255 
5   PICT  125  098    400   400    14860       15610    1      ""                                 255 255 255 
6   PICT  209  235    400   400    30471       17231     2      ""                                 255 255 255 
7   PICT  115  088    400   400    47703       14978     3      ""                                 255 255 255 




17  SND   0    0    0     0      4         0000           0     "c3s4end.mp3"                        0   0   0 

18 WND    0    0    0     0      0   62682   0  ""  0 0 0      

