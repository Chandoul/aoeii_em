ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  120  100  430   200    00000      36316       3     "It was a catastrophic battle, one of the largest and greatest the world has ever seen.  The stream was turned to a torrent by the rushing of blood.  I pity those that were forced to slake their thirst from it.  �Cadavera vero innumera�, the Romans said afterwards.  �Truly countless bodies.�  Perhaps 300,000 men were left dead on the Catalaunian fields.  It is said the ghosts of those killed continued to fight for several days."         0   0   0   
2   TEXT  130  160  300   240    36316      26935       3     "I passed within inches of the fell Hun king as he stalked the battlefield, trying to determine which of his chieftains and allies yet lived.  When he found me, huddled beneath my shield, I made my peace with God.  But Attila did not seek my decapitation.  He saw that I was a holy man, and ordered me to join his retinue of foreign advisors.  �That is how you know so much of the Huns,� I offered."         0   0   0   
3   TEXT  191  120  400   200    63251      26470       3     "The priest nodded. Despite the carnage, the outcome of the legendary battle was unclear.  Attila had lost much of his cavalry, but the Romans' entire army was destroyed.  For a time, no one knew if the Hun king would continue to pursue the hand of Honoria.  �But what of the prophecy?�  I asked.  �Did Aetius die on the battlefield?�"         0   0   0   
4   TEXT  340  150  350   200    89721      19504       3     "�Nay.  It was Theodoric the Goth, not Aetius, who died and fulfilled the prophecy.  Aetius knew that if he utterly destroyed the Huns, then the Visigoths would have no need for a Roman alliance and Rome would face yet another barbarian threat."         0   0   0   
5   TEXT  241  100  350   200   109226      18210       3     "And so, Aetius retired from military life, hoping that the outcome of the Catalaunian fields would leave the Huns and Goths in a stalemate, hoping that he had done enough to save his empire.  He had not."         0   0   0   

6   PICT  193  197  400   400   00000      36316       0     ""                                 255 255 255 
7   PICT  385  096  400   400   36316      26935       1     ""                                 255 255 255 
8   PICT  112  268  400   400   63251      26470       2     ""                                 255 255 255 
9   PICT  091  119  400   400   89721      19504       3     ""                                 255 255 255 
10  PICT  306  129  400   400  109226      18210       4     ""                                 255 255 255 


17  SND   0    0    0     0     4         00000       0     "xc1s5end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         127436       0     ""  0 0 0      

