ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204   100   475    400    0000      14958        0     "An army marches on its stomach, or so the old saying goes. My Clansmen have been farming and tending sheep for hundreds of years � but gathering enough food to feed an army is a different matter entirely."     66 57 20   
2   TEXT  140   90   400    400    14958      7750        0     "Without a strong economy, the meager forces that we have cobbled together will collapse again."     66 57 20

3   PICT  107   159   400   400    0000      14958        0     ""                                 255 255 255 
4   PICT  223   110   400   400    14958      7750        1     ""                                 255 255 255 

5   SND     0     0     0     0       0      22709        0     "c8s2.mp3"                        0   0   0 

6  WND      0     0     0     0       0      22709        0     ""        0 0 0      
