ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  340  200  300   400    00000     23312        3     "Passed down to you by Cuauhtemoc, Emperor of Tenochtitlan.  The death of Montezuma only served to further inflame the fury of my people.  I planned to lead the attack personally against the Spanish.  �That is as it should be, Cuauhtemoc,� the priests told me, �for you are now our emperor.�" 12  9  4 
2   TEXT  160  130  300   200    23312     10309        3     "I took my place on the icpalli throne and the headdress of the emperor was placed upon my head.  A crown is never a comfortable thing to wear." 12  9  4 
3   TEXT  130  110  500   350    33622     12538        3     "Cort�z had still not made it far from Tenochtitlan, for the Spanish were weighted down with our stolen gold.  As they fled around the shores of the lake, my warriors pursued them from canoes." 12  9  4 
4   TEXT  130  150  200   350    46161     15197        3     "I sent additional warriors by land, for it was obvious now that Cort�z was attempting to flee back to the safety of his allies in Tlaxcala.  We caught up with the Spanish on the north side of Lake Texcoco." 12  9  4 


5   PICT  155  101  400   400    00000     23312        0     "" 0 0 0
6   PICT  315  186  400   400    23312     10309        1     "" 0 0 0
7   PICT  274  226  400   400    33622     12538        2     "" 0 0 0
8   PICT  352  104  400   400    46161     15197        3     "" 0 0 0





16  SND   0    0    0     0      4          0000        0     "xc3s5.mp3" 0 0 0 

17  WND   0    0    0     0      0          61358        0     "" 0 0 0      
