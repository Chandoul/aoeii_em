ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  199  407  434   300    00000      15794       3     "As we rode into Rheims, a sea of peasants and lords knelt before Joan. Some even knelt to kiss her horse's hoofprints. Cannon thundered and a thousand flags danced in the breeze."     0   0   0   
2   TEXT  143  274  270   600    15794      14036       3     "In the enormous palace, the Dauphin knelt before the archbishop and rose as King of France. Prayers, anthems, and sermons filled the great ch�teau. "     0   0   0   
4   TEXT  217  100  400   085    29831      09013       3     "Interspersed among perfumed dukes and ladies were tattered soldiers from our army, many still bearing wounds."     0   0   0   
5   TEXT  217  100  400   085    38844      06366       3     "Joan herself was at the king's side, as was her bedraggled battle standard."     0   0   0   
6   TEXT  153  095  280   090    45211      10222       3     "Despite the celebration, I know in my heart that this war is far from over. Our fathers and grandfathers died fighting against the English."     0   0   0   
7   TEXT  153  095  250   085    55433      10905       3     "Joan gives us hope, but I do not know if hope is enough to ensure victory."     0   0   0   

8    PICT  129   94   400   400    00000      15794     0     ""                                 255 255 255 
10   PICT  427  063    400   400    15794      14036     1      ""                                 255 255 255 
11   PICT  156  182   400   400    29831      15380     2      ""                                 255 255 255 
12   PICT  322  115   400   400    45211      21127     3      ""                                 255 255 255 

17  SND   0    0    0     0      4         0000           0     "c1s4end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   66339   0  ""  0 0 0      

