ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  420   266   300    400    0000      04922       0     "We are without a leader. The dead king of Scotland has no heir."     66 57 20
2   TEXT  100   206   300    400    04922     18482         0     "War creeps in from the south, where Edward Longshanks, the avaricious King of England, has returned from successful campaigns to conquer Wales and France. As Longshanks turns his attention to Scotland, the shadow of fear settles across the Highlands."     66 57 20
3   TEXT  240   400   300    400    23405     07127        0     "The English have thousands of Welsh longbowmen, hundreds of knights on horseback, and dozens of siege weapons."     66 57 20
4   TEXT  420   266   300    400    30533     20411        0     "We Scottish have a rabble of untrained soldiers who do not even know how to march in a straight line. We must act soon. If we have any chance of resistance, we need to forge an army by any means necessary."     66 57 20


5   PICT  078  090  400   400     0       04922        0     "" 0 0 0
6   PICT  349  114  400   400    04922    18482      1    "" 0 0 0
7   PICT  217  036  400   400    23405    07127      2     "" 0 0 0
8   PICT  121  076  400   400    30533    20411       3     "" 0 0 0

5   SND      0     0     0     0       0     23835        0     "c8s1.mp3"                        0   0   0 
6  WND      0     0     0     0       0     50944        0     ""        0 0 0      

