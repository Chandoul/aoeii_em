ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  400  110  280  170    00000      16625       3     "The Battle of Agincourt is remembered not because it was an inevitable triumph, but because it was an upset.  Outnumbered English longbows were victorious over French knights only because the knights had to charge up a muddy hill through a dense forest."     0   0   0   
2   TEXT  400  110  270  150    16625      15812       3     "The English wore little armor, and were able to catch the encumbered French in the middle of their retreat.  A charge by Henry and his surviving cavalry pushed aside the beaten French and opened the road to the coast."     0   0   0   
3   TEXT  230  110  450  100    32437      16324       3     "Despite his victory, Henry did not follow through on his attack, but withdrew to England.  The true winner of the battle was Burgundy, which was able to come to power in a vacuum emptied by both the English and the French."     0   0   0   


4   PICT  033  105  400   400   00000      32437       0     ""                                 255 255 255 
5   PICT  106  200  400   400   32437      16324       1     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc4s5end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         48761       0     ""  0 0 0      

