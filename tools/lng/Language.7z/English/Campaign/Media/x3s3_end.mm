ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  141  110  300   200    00000      19681       3     "Although the Aztec warriors fought well that day, my men were frightened by the beasts that the Spanish rode into combat, and by the noise of their exploding weapons.  Although we had survived the attack, I thought it best to withdraw towards Tenochtitlan, and share with Emperor Montezuma all that we had learned."     12 9 4  
2   TEXT  241  390  450   168    19681      14962       3     "I do not know if my uncle, Montezuma, was being cowardly or merely trying to preserve us from the wrath of the gods, but he sent more gifts to Cort�z along with an invitiation to visit our great city as his personal guest."     12 9 4  
3   TEXT  130  120  350   168    34644      20742       3     "I was there when Montezuma met Cort�z on one of the causeways leading into our great city.  The Spanish had evidently never seen anything like Tenochtitlan, and they stared in wonder at the brightly colored markets and pyramids rising out of a man-made island in the middle of gigantic Lake Texcoco."     12 9 4  
4   TEXT  270  120  350   168    55387      10371       3     "Some of the Spanish soldiers asked whether it was all a dream, the first glimpse of things never heard, seen or dreamed before."     12 9 4  
5   TEXT  140  250  300   368    65758      26314       3     "Montezuma led Cort�z at the top of the Great Pyramid, where he pointed out the various canals and neighborhoods of the city.  But Cort�z was mostly interested in gold ornaments, and helped himself to any which he encountered.  I was no longer convinced that this man was Quetzalcoatl.  So says Cuauhtemoc, Jaguar Warrior of Tenochtitlan."     12 9 4  


6    PICT  365  148  400   400   00000      19681       0     ""                                 255 255 255 
7    PICT  112  104  400   400   19681      14962       1     ""                                 255 255 255 
8    PICT  332  150  400   400   34644      20742       2     ""                                 255 255 255 
9    PICT  109  212  400   400   55387      10371       3     ""                                 255 255 255 
10   PICT  365  148  400   400   65758      26314      4     ""                                 255 255 255 




17  SND   0    0    0     0     4         00000       0     "xc3s3end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         92072       0     ""  0 0 0      

