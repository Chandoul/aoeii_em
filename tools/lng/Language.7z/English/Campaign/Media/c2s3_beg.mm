ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204  306  454   0032   00000       10843       2    "Galilee.  Year twenty of my capture �"     0   0   0   
2   TEXT  153  421  560   0100   10843       11704       2    "Last night, we rode into a sandstorm. The men dared not open their mouths to speak. We clung to the necks of horses or camels while waves of sand rose and fell around us."     0   0   0   
3   TEXT  174  393  498   0126   22548       14696       2    "The Saracens have pursued a large force of Europeans into the desert. The Crusaders carry with them a relic � a piece of the True Cross. Capturing this artifact will deal a severe blow to the morale of Saladin's Christian foes."     0   0   0   
4   TEXT  196  241  356   0300   37244       09015       2    "I asked Saladin why we were here, miles from civilization and water. He said 'to bring crimson death to the blue-eyed enemy.' "     0   0   0   
5   TEXT  150  415  570   0100   46260       11604       2    "The huge Crusader army has halted to make its stand beneath the two peaks called the Horns of Hattin. At the Horns is only a single pool of water, and Saladin controls it."     0   0   0   
6   TEXT  125  200   368   0124   57864       13804       2    "At night, the Saracens ride out and extravagantly pour out vessels of water into the sand within sight of the thirst-crazed Europeans. It is cruelty worthy of a � Crusader."     0   0   0   

7   PICT  114 78   400   400     10843     11704       0     ""                                 255 255 255 
8   PICT  118 90   400   400     22548     14696       1     ""                                 255 255 255 
9   PICT  331 236   400   400    37244     09015       2     ""                                 255 255 255 
10   PICT  198 79   400   400     46260     11604       3     ""                                 255 255 255 
11  PICT  358 78   400   400     57864     13804       4     ""                                 255 255 255 




17  SND   0    0    0     0      0000         1000           0     "c2s3.mp3"                        0   0   0 
18 WND    0    0    0     0      0  71668   0  ""  0 0 0      

