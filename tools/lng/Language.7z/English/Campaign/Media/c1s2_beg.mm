ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  339  299  144   500    0000       02630        3     "March 26, Chinon"     0   0   0
2   TEXT  470  350  220   500    02630      12314        3     "It is one thing for a band of dispirited soldiers to put their trust in a teenage girl. It is entirely another for that girl to be given command of the army of an entire nation."     0   0   0
3   TEXT  378  130  336   075    14944      07841        3     "We were filled with pride when we heard the Dauphin's heralds pronounce Joan the Maid as Commander of the Army of France."     0   0   0
4   TEXT  470  350  220   500    22786      07585        3     "So that she may look like a general, the Dauphin presented Joan with a great warhorse and a suit of white armor."     0   0   0
5   TEXT  373  170  332   500    30371      07174        3     "Joan instructed me to look for an ancient sword buried beneath the altar of a local church."     0   0   0
6   TEXT  184  152  478   500    37546      18724        3     "I was skeptical, but not only did the men unearth a rusted blade, but we found that the sword belonged to Charlemagne, grandfather of France. I shall not doubt her word again. Still visible on the hilt was the fleur-de-lis."     0   0   0
7   TEXT  324  264  384   700    56271      13482        3     "Joan adopted the fleur-de-lis as her symbol and had it blazoned upon her battle standard. Wherever Joan goes, the standard goes also. It goes with us to Orl�ans."     0   0   0
8   TEXT  365  425  340   700    69753      11317        3     "The City of Orl�ans is one of the finest in France, but it is under siege by our enemies, England and Burgundy, and is about to fall. "     0   0   0
9   TEXT  154  148  548   500    81070      21097        3     "This war has dragged on for one hundred years with precious few French victories. The people of Orl�ans need a savior. They are to get Joan of Arc."     0   0   0



10   PICT  126  91    400   400    02630     20156        0     ""                                 255 255 255
11   PICT  136  089   400   400    22786     07585        1     ""                                 255 255 255
12   PICT  120   157  400   400    30371     07174        2     ""                                 255 255 255
13   PICT  341  259   400   400    37546     18724        3     ""                                 255 255 255
14   PICT  155  104   400   400    56271     13482        4     ""                                 255 255 255
15   PICT  103   84   400   400    69753     11317        5     ""                                 255 255 255
16   PICT  179  236   400   400    81070     21097        6     ""                                 255 255 255


18 WND    0    0    0     0      0   102167   0  ""  0 0 0      



15  SND   0    0    0     0      0000      15000       0     "c1s2.mp3"                     0   0   0 

