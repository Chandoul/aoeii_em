ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  130  128  332   134   0000       15975       4    "Now all of Mongolia is in the grasp of Genghis Khan. Beyond are two vast empires: China to the east and Persia to the west. Persia is the sensible next choice of battle, since it separates us from the rich forage pastures in Europe."     37 15 9
2   TEXT  166  445  434   044   15975      03900        4    "But first, Genghis Khan has another score to settle."     37 15 9
3   TEXT  436  126  242   142   19876       09380        4    "After witnessing the power of our cavalry in action, the Chinese spoke of nothing but peace. They even promised support for our campaign westward. "     37 15 9
4   TEXT  220   194  400   0070   29251      07362        4    "But now that we have turned away from China, they have decided not to deliver the men and arms they promised Genghis."     37 15 9
5   TEXT  115  466  574   0080   36613      16630        4    "It is time for another demonstration. Persia can wait as the Horde wheels east once more, and we prepare to march into China, the largest, most advanced empire in the world."    37 15 9



8   PICT  281  114   400   400    00000      15975       0     ""                                 255 255 255 
9   PICT  343  120   400   400    15975      03900      1     ""                                 255 255 255 
10   PICT  98   124   400   400    19876      09380      2     ""                                 255 255 255 
11  PICT  185  278   400   400    29251      07362      3     ""                                 255 255 255 
12  PICT  198  85    400   400    36613      16630       4     ""                                 255 255 255 




17  SND   0    0    0     0      0001         1000           0     "c3s3.mp3"                        0   0   0 
18 WND    0    0    0     0      0   53243     0  ""  0 0 0      

