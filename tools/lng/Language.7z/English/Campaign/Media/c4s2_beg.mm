ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  133  129  520   500    00000      13803       3     "The empire was in full bloom, and her population was rapidly expanding. The Germans felled forests, drained marshlands, and reclaimed land from the sea itself. But there was still not enough space."     0   0   0
2  TEXT  120  355  275   500    13803      06464        3     "Bringing the vastness of Poland into the empire would ease the pressure on the empire's borders."     0   0   0
3  TEXT  150  135  520   500    20267      12833       3     "To deal with Poland, Barbarossa called up one of his mightiest vassals, Henry the Lion.  Henry was a powerful prince of Saxony, and his decadent palaces outshown the emperor's own."     0   0   0
4  TEXT  126  153  450   500    33100      07777        3     "While he swore fealty to Barbarossa, some questioned whether Henry the Lion did not want the Empire for his own."     0   0   0
5  TEXT  300  135  400   500    40877      13108       3     "By ordering Henry the Lion to aid in the subjugation of Poland, Barbarossa meant to test his oath of allegiance once and for all."     0   0   0

6   PICT  254  226   400   400    00000      13803        0     ""                                 255 255 255
7   PICT  144  60    400   400    13803      06464       1     ""                                 255 255 255
8   PICT  290  222   400   400    20267      12833        2     ""                                 255 255 255
9   PICT  73  90     400   400    33100      07777       3     ""                                 255 255 255
10   PICT  105  210   400   400    40877      13108        4     ""                                 255 255 255

18 WND    0    0    0     0      0   53986   0  ""  0 0 0      



15  SND   0    0    0     0      0       15000       0     "c4s2.mp3"                     0   0   0 

