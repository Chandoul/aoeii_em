ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  170  286  500   60     00000      08674       2     "Egypt. A month since I entered the Holy Land �"     0   0   0   
2   TEXT  210  413  500   450    08674      03863       2     "I was in a foreign land. And I was dying."     0   0   0   
3   TEXT  139  222  366   194    12538      11888       2     "I wandered the cold desert for four nights before the horse archers found me. I had abandoned my mount to the vultures and my armor to the heat of day. As a knight, I was not much of a threat to them."     0   0   0   
4   TEXT  138  97   578   172    24427      19133       2     "I thought these men were Turks, come to toy with their prey. But when I could distinguish the riders from the blur of mirage I saw that they were Saracens, the rulers of the Middle East. I had ridden to the Holy Land with the Crusaders from France and Normandy, so I was by all rights these Saracens' enemy. "     0   0   0   
5   TEXT  267  448  434   64     43560      05201       2     "Yet they gave me water and a spindly horse and led me back to their leader."     0   0   0   
6   TEXT  152  145  350   340    48761      23034       2     "And that was how I met Saladin. The paintings in Europe show Saladin as demonic, barbarian. Yet he is more chivalrous than any knight I'd met before and prefers the palaces of Damascus to slaughtering Normans in the desert. I had not expected hospitality from Saracens � we Normans execute any armed Arab we capture."     0   0   0   
7   TEXT  144  92   544   98     71796      08631       2     "But Saladin left me free to explore his camp. Perhaps he wants an objective observer to chronicle the prodigious bloodshed ahead."     0   0   0   
8   TEXT  459  155  262   376    80427      15795       2     "Saladin's army is heading south to Egypt to reinforce Cairo. Egypt is a tempting prize for the Crusaders. She is fabulously wealthy, yet governed by an ineffectual fool. Before my capture, I was en route to join in the Crusaders' assault on Egypt."     0   0   0   
9   TEXT  155  355  280   98     96223      17507       2     "It is a bitter irony that now I shall view the contest from the enemy camp. So it was that"     0   0   0   
10  TEXT  155  451  540   80     96223      17507       2     "I found myself less than a hundred miles from the Dead Sea, in the company of my enemies."     0   0   0   



11   PICT  132   132   400   400    08674      03863       0     ""                                 255 255 255 
12   PICT  434   84    400   400    12538      11888       1     ""                                 255 255 255 
13   PICT  276   221   400   400    24427      19133       2     ""                                 255 255 255 
14   PICT  99    79    400   400    43560      05201       3     ""                                 255 255 255 
15   PICT  503   114   400   400    48761      23034       4     ""                                 255 255 255 
16   PICT  105   192   400   400    71796      08631       5     ""                                 255 255 255 
17   PICT  145   106   400   400    80427      15795       6     ""                                 255 255 255 
18   PICT  265   78    400   400    96223      17507       7     ""                                 255 255 255 



19 SND   0    0    0     0      4         0              0     "c2s1.mp3"                        0   0   0 
20 WND   0    0    0     0      0         113731         0     ""                                0   0   0      
