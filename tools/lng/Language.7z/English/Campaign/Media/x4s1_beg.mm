ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  120  110  450   135    00000      27492       3     "It is impossible to imagine the world ending on such a fine fall day.  Yet the storm of Moslem horses continues to rage throughout Europe, leaving conquered cities and shattered armies stunned in its wake. The lightning-quick strikes of the Moslem horses break the city of Bordeaux, and then Poitiers, leaving precious little of the Frankish kingdom to defend."     0   0   0   
2   TEXT  120  110  450   100    27492      07430       3     "Yet, Charles Martel gathers the disheartened Frankish army for one last stand at the city of Tours."     0   0   0   
3   TEXT  190  110  450   100    34922      16253       3     "Moslem horses, bred for speed and beauty, begin to splash across the Vienne River.  Martel�s knights and swordsmen, trudging under the weight of iron mail, struggle to interpose themselves between the Moslems and the city of Tours. "     0   0   0   
4   TEXT  190  110  450   100    51176      16422       3     "Carrion birds circle in the air, anticipating the savagery to come.  The rest of Europe watches anxiously, for this is the climax of the Moslem invasion and the last stand of Christian Europe."     0   0   0   



5   PICT  313  232  400   400   00000      34922       1     ""                                 255 255 255 
6   PICT  159  219  400   400   34922      67599       2     ""                                 255 255 255 



15  SND   0    0    0     0     4         00000       0     "xc4s1.mp3"                        0   0   0 
16  WND   0    0    0     0     0         67599       0     ""  0 0 0      

