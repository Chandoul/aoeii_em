ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  100   100   415    400    0000      18669       0     "Rumors creep in from the south of a giant who leads the forces of Scotland, his great sword driving through earth and man and horse alike. If this mythical knight can hold the English advance, it will give us time to develop the arms we need."     66 57 20
2   TEXT  204   100   475    400    18669      7969       0     "Even now our smiths are forging swords, and fletchers are making arrows and crossbow bolts."     66 57 20

3   PICT  405   100   400   400    0000      18669       0     ""                                 255 255 255 
4   PICT  116    92   400   400    18669      7969       1     ""                                 255 255 255 

5   SND     0     0     0     0       0     26639        0     "c8s4.mp3"                        0   0   0 

6   WND     0     0     0     0       0     26639        0     ""        0 0 0      
