ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  170  420  475   200    00000      12870       3     "The Spanish called it la noche triste, which meant �the night of sorrows� in their language.  At first the Spanish barricaded themselves in our homes and palaces, but we continuously attacked their quarters."     12 9 4   
2   TEXT  410  120  300   200    12870      11092       3     "With stones, slings and arrows, we drove the Spanish and Tlaxcalans through the streets of Tenochtitlan and across the three bridges or over the walls into Lake Texcoco."     12 9 4   
3   TEXT  241  150  350   168    23962      16997       3     "Thousands died.  Those Spanish that were not killed by macanas or javelins, were drowned by the weight of the treasure they refused to leave behind.  Tenochtitlan lay in ruin, but the city was ours again."     12 9 4   
4   TEXT  241  150  350   168    40960      22227       3     "Many brave Aztec warriors died that night as well, including noble Montezuma.  The Spanish claimed that our own people had killed him with thrown stones.  Thus it was a night of sorrows for us as well.  So says Cuauhtemoc, defender of Tenochtitlan."     12 9 4   


5   PICT  113  102  400   400   00000      12870       0     ""                                 255 255 255 
6   PICT  131  175  400   400   12870      11092       1     ""                                 255 255 255 
7   PICT  145  282  400   400   23962      16997       2     ""                                 255 255 255 
8   PICT  199  320  400   400   40960      22227       3     ""                                 255 255 255 


17  SND   0    0    0     0     4         00000       0     "xc3s4end.mp3"                        0   0   0 
18  WND   0    0    0     0     0         63187       0     ""  0 0 0      

