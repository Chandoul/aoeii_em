ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  115  090  550   130    00000      30371       3     "The ships slide through a mirror-flat ocean stained red with spring seaweed.  Columns of rock improbably draped with pine trees tower out of the mist.  The men on the ships watch silently as the samurai prowl the deck above.  They will make land near Kyoto and their lord, Hideyoshi, will lead the siege of the city of ten-thousand shrines."     0   0   0   
2   TEXT  115  090  550   130    30371      24520       3     "Within Kyoto, revolutionaries hold prisoner Lord Nobunaga -- the man who would unify Japan. The islands of Japan remain a patchwork of bickering samurai warlords who still settle conflicts with ritualized duels.  Nobunaga seeks to forge a single Japan, dragging the provincial samurai into the modern era.  "     0   0   0   
3   TEXT  115  090  550   100    54891      29222       3     "Like his master Nobunaga, Hideyoshi wins his battles by volleys of muskets, fully exploiting the firearms recently introduced by Portuguese sailors. Hideyoshi intends no bargaining -- he will demand once for Nobunaga�s release, and then storm the city."     0   0   0   


4   PICT  237  290  400   400   00000      54891       1     ""                                 255 255 255 
5   PICT  097  190  400   400   54891      29222       0     ""                                 255 255 255 

15  SND   0    0    0     0     4         00000       0     "xc4s7.mp3"                        0   0   0 
16  WND   0    0    0     0     0         84114       0     ""  0 0 0      

