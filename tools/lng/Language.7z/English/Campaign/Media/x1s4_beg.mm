ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  160  120  300   200    00000     21398        3     "The Western Roman emperor had a sister named Honoria, who after weary years of confinement to her parlor, made the preposterous decision to send a letter to Attila the Hun.  She asked him to marry her.  One suspects Honoria did not know what she was getting into." 12  9  4 
2   TEXT  190  110  450   200    21398     24298        3     "Attila was plentifully supplied with wives, but he immediately saw the advantage that such a union could put him in.  Suddenly, his plans changed.  He would not invade the Eastern Roman Empire at Constantinople, but the Western Empire, at Rome.  Indeed, he claimed half of the Western Empire as his dowry." 12  9  4 
3   TEXT  140  235  270   200    45696     21176        3     "Attila sent the Huns to march across the Rhine River, and made alliances with the other barbarian chieftains.  Some, namely the Burgundians and Ostrogoths, joined the Hun confederation, while others, such as the Visigoths, sought to seek Roman favor by opposing the Huns." 12  9  4 
4   TEXT  160  200  300   200    66873     10692        3     "When Attila entered Gaul, what we now call France, he could claim that he merely sought by force what was his by right of betrothal to Honoria." 12  9  4 


5   PICT  190  163  400   400    00000     21398        0     "" 0 0 0
6   PICT  156  200  400   400    21398     24298        1     "" 0 0 0
7   PICT  339  128  400   400    45696     21176        2     "" 0 0 0
8   PICT  211  143  400   400    66873     10692        3     "" 0 0 0

16  SND   0    0    0     0      4          00001        0     "xc1s4.mp3" 0 0 0 

17  WND   0    0    0     0      0          77566        0     "" 0 0 0      
