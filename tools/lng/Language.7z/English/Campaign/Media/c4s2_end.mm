ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1  TEXT  155  425  520   500    00000      17136        3     "Henry expected to be drawn and quartered, the usual fate of traitors in those times. But Barbarossa recognized the potential for a strong ally and officially forgave him, provided that Henry the Lion would swear to support Barbarossa from now on."     0   0   0
2  TEXT  155  352  520   500    17136      03508        3     "Amazingly, Henry agreed."     0   0   0
3  TEXT  157  127  520   500    20644      21900        3     "Germany was unified, and Henry the Lion was pacified. But the Holy Roman Empire was not complete. Harkening back to Charlemagne, the empire claimed ownership of Italy, and especially Rome."     0   0   0

4   PICT  94   59   400   400    00000      17136        0     ""                                 255 255 255
5   PICT  323  83   400   400    17136      03508        1     ""                                 255 255 255
6   PICT  80  190   400   400    20644      21900        2     ""                                 255 255 255

18 WND    0    0    0     0      0   42388  0  ""  0 0 0      



15  SND   0    0    0     0      0000      15000       0     "c4s2end.mp3"                     0   0   0 

