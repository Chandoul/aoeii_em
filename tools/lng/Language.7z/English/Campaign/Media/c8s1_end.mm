ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  380   100   350   400    0000      14123        0     "Scotland has soldiers now, if only a few. But if we are to turn back the greed of Edward Longshanks, we will need many more recruits, and much more gold in our coffers."     66 57 20   
2   TEXT  380   330   350   400    14123     9711         0     "These ancient stones and oaks around us will soon be steeped in the blood of Clansmen."     66 57 20   

3   PICT  85    102   400   400    0000      14127        0     ""                                 255 255 255 
4   PICT  123   114   400   400    14123     9711         1     ""                                 255 255 255

5   SND      0     0     0     0       0     23835        0     "c8s1end.mp3"                        66 57 20 

6   WND      0     0     0     0       0     23835        0     ""        0 0 0      
