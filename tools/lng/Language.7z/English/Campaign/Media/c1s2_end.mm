ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  400  250  300   500    00000      10943       3     "Joan prophesied that she would be wounded at Orl�ans. At the height of the battle, an arbalest bolt knocked her from her horse. We could not believe our misfortune."     0   0   0   
2   TEXT  400  250  300   500    10943      08282       3     "But as we carried Joan away from the carnage, the battle was won. Orl�ans was free."     0   0   0   
3   TEXT  120  295  280   600    19226      06853       3     "When we entered the city, the entire population cheered us on from windows, rooftops, and city streets."     0   0   0   
4   TEXT  120  295  280   600    26079      15252       3     "They fired artillery into the night sky and shouted aloud their nickname for Joan: 'La Pucelle'�The Maid of Orl�ans."     0   0   0   

8   PICT  109  087  400   400    00000      19226       0     ""                                 255 255 255 
9   PICT  385  095  400   400    19226      22105       1     ""                                 255 255 255 

17 SND   0    0    0     0      4         0000           0     "c1s2end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   41331  0  ""  0 0 0      

