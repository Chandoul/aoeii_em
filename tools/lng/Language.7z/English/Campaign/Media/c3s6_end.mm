ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE
0   TEXT  200  436  430   300    00000   11662       4     "Nothing stands between us and the Atlantic Ocean. The Mongol empire comprises two whole continents; Europe and Asia belong to the Hordes."     37 15 9 
1   TEXT  417  248  244   300    11662   14348       4     "Every place we entered has changed forever with our passing. Russia, once filled with quarreling city-states, much like ancient Mongolia, will forever be melded into a single, gigantic nation."     37 15 9 
2   TEXT  182  095  400   200    26010   25007       4     "Genghis Khan forged the largest empire ever created in the life of one man. His body was carried back to the River Onon, where the legendary Blue Wolf and Fallow Doe once lived. He was buried in the ground and a thousand horsemen rode over the site to disguise it. Genghis Khan's final resting place was devoured by the steppes."     37 15 9 
3   TEXT  132  117  356   300    51018   51018       4     "My people cherish the legend that their great ruler will one day return to lead his horsemen to another bloody victory."     37 15 9 




4   PICT  106    97    400   400    00000     11662        0     ""                                 255 255 255 
5   PICT  084    87    400   400    11662     14348        1     ""                                 255 255 255 
6   PICT  132    209   400   400    26010     25007        2     ""                                 255 255 255 
7   PICT  269    139   400   400    51018     51018        3     ""                                 255 255 255 




17  SND   0    0    0     0      4         0000           0     "c3s6end.mp3"                        0   0   0 
18 WND    0    0    0     0      0   66989   0  ""  0 0 0      

