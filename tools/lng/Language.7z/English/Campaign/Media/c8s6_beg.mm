ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  420   266   300    400    0000      9019        0     "Our coffers were depleted at the Battle of Stirling, so we need to strengthen our economy once again before pushing south into lands held by the English."     66 57 20
2   TEXT  420   186   300    400    9019      7187        0     "We need to construct a market and establish trade routes to the villages of friendly clans."     66 57 20
3   TEXT  204   085   475    400    16207     10901       0     "Local legends speak of three sacred relics hidden south of Stirling. Acquiring these artifacts for Wallace's army will be a great boost to Scottish morale."     66 57 20

4   PICT   44    57   400   400    0000      9019        0     ""                                 255 255 255 
5   PICT  129    94   400   400    9019      7187        1     ""                                 255 255 255 
6   PICT  186   117   400   400    16207     10901       2     ""                                 255 255 255 

7   SND     0     0     0     0       0     27109        0     "c8s6.mp3"                        0   0   0 

8   WND     0     0     0     0       0     27109        0     ""        0 0 0      
