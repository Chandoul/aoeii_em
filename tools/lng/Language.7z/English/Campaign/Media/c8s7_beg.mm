ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  204  100   475    400    0000       11517       0     "The only way we can hold the boggy lowlands around Falkirk is to build a castle and as many walls as we can construct in a short time."     66 57 20
2   TEXT  204  085   475    400    11517      8951        0     "These fortifications will serve to protect our camp as we construct siege weapons with which to assault the English castle."     66 57 20
3   TEXT  204  085   475    400    20468      10599       0     "Once the castle is constructed, Wallace himself has sworn to join our forces and together we will attack Longshanks and his English troops."     66 57 20

4   PICT  116   79   400   400    0000       11517       0     ""                                 255 255 255 
5   PICT  85    89   400   400    11517      8951        1     ""                                 255 255 255 
6   PICT  127  170   400   400    20468      10599       2     ""                                 255 255 255 

7  SND     0     0     0     0       0     31068        0     "c8s7.mp3"                        0   0   0 

8  WND     0     0     0     0       0     31068        0     ""        0 0 0      
