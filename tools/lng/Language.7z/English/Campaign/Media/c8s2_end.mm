ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  375   100   320   400    0000      22894       0     "Edward Longshanks, for all his disrepute, has shown military tactics in Wales, England, and France to be very effective, if not cruel and ruthless. He is indeed an enemy to be feared. The English sacked the town of Berwick-upon-Tweed. Would that I could call it a battle, but it was truly more of a massacre."     66 57 20
2   TEXT  100   450   475    400    22894     10495       0     "Unless we organize our army, there will be more massacres to follow. I pray we can be ready for Longshanks coming."     66 57 20

3   PICT  67    18    400   400    0000      22894       0     ""                                 255 255 255 
4   PICT  297   46    400   400    22894     10495       1     ""                                 255 255 255 w

5   SND     0     0     0     0       0     33390        0     "c8s2end.mp3"                        0   0   0 

6  WND      0     0     0     0       0     33390        0     ""        0 0 0      
