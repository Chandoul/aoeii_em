ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE

1   TEXT  180   100   475    400    0000      8621        0     "With the three relics locked away safely in Scottish churches, men murmur that we are blessed by the heavens."     66 57 20 
2   TEXT  204   100   475    400   8621      10639       0     "Our army now stands a chance as we prepare for the final clash with the English.  Scotland now has archers and knights of our own with which to meet Longshanks."     66 57 20 
3   TEXT  100   240   250    400   19260     15197       0     "We march south, to Falkirk, where we will rendezvous with the army of William Wallace and plan our combined attack upon the English castle."     66 57 20 

4   PICT  110   124   400   400    0000      8621        0     ""                                 255 255 255 
5   PICT   68   130   400   400    8621      10639       1     ""                                 255 255 255 
6   PICT  291    54   400   400    19260     15197       2     ""                                 255 255 255 

7   SND     0     0     0     0       0     34458        0     "c8s6end.mp3"                        0   0   0 

8   WND     0     0     0     0       0     34458        0     ""        0 0 0      
