ID  TYPE  X    Y    WIDTH HEIGHT STARTTIME DISPLAYTIME FRAME STR TEXTCOLORRED TEXTCOLORGREEN TEXTCOLORBLUE


1   TEXT  151  396  558   144    00000     19231        2     "The Franks are dispersed, and the Egyptian army broken. Saladin has taken his place as governor of the Nile. Any European king would seize this opportunity to eliminate his political enemies. Saladin, however, allowed any Egyptian opposed to his rule to leave the city unharmed."     0   0   0   
2   TEXT  207  95  508    172    19231     22900        2     "Saladin has set out to win over the population. In Cairo, he built mosques and palaces, universities and hospitals. My own countrymen, the sons of Europe, showed naught but treachery, while the Saracens work to dignify their civilization. It is a troubling turn of events and I have difficulty sleeping."     0   0   0   


8   PICT  109   84   400   400    00000      19231        0     ""                                 255 255 255 
9   PICT  94   202   400   400    19231      22900        1     ""                                 255 255 255 


17  SND   0    0    0     0      4         0000           0     "c2s1end.mp3"                        0   0   0 
18  WND    0    0    0     0      0   42132   0  ""  0 0 0      

